// ─────────────────────────────────────────────────────────
// MobileSidebar.jsx — slide-in drawer for mobile
// ─────────────────────────────────────────────────────────
import { NavLink } from 'react-router-dom';
import { SIDEBAR_ALL } from './navConfig';
import { ThemeToggle } from './ThemeToggle';

export const MobileSidebar = ({ open, onClose, user, isAuth, onLogout }) => {
  return (
    <>
      {open && (
        <div
          className="lg:hidden fixed inset-0 z-50 bg-black/40 backdrop-blur-sm"
          onClick={onClose}
        />
      )}

      <aside
        className={`
          lg:hidden fixed inset-y-0 left-0 w-72
          border-r shadow-2xl flex flex-col
          transition-transform duration-300 ease-in-out sidebar-root
          ${open ? 'translate-x-0' : '-translate-x-full'}
        `}
        style={{ zIndex: 60 }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-5 pb-4 shrink-0">
          <NavLink to="/" onClick={onClose} className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gray-900 flex items-center justify-center text-white font-black text-sm font-mono">Q</div>
            <div className="leading-none">
              <div className="font-black text-base tracking-tight sidebar-text-strong">Qtemplate</div>
              <div className="text-[9px] font-semibold tracking-widest uppercase mt-0.5 sidebar-text-muted">Marketplace</div>
            </div>
          </NavLink>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl flex items-center justify-center text-lg leading-none sidebar-nav-item"
          >×</button>
        </div>

        <div className="mx-5 h-px sidebar-divider shrink-0" />

        {/* User card */}
        {isAuth && (
          <div className="px-4 py-3 shrink-0">
            <div className="flex items-center gap-3 px-3 py-3 rounded-xl border sidebar-user-card">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-pink-500 flex items-center justify-center text-white font-bold text-sm shadow-sm shrink-0">
                {user?.fullName?.[0]?.toUpperCase() || 'U'}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold truncate sidebar-text-strong">{user?.fullName || 'Người dùng'}</p>
                <p className="text-xs capitalize truncate mt-0.5 sidebar-text-muted">{user?.role || 'Member'}</p>
              </div>
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 shrink-0 ring-2 ring-white/20" />
            </div>
          </div>
        )}

        <div className="px-5 pb-2 shrink-0">
          <span className="text-[10px] font-bold uppercase tracking-widest sidebar-label">Tài khoản</span>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto min-h-0 px-4 pb-4 space-y-0.5">
          {isAuth ? (
            SIDEBAR_ALL.map(({ path, icon, label }) => (
              <NavLink
                key={path}
                to={path}
                onClick={onClose}
                className={({ isActive }) => `sidebar-nav-item ${isActive ? 'active' : ''}`}
              >
                {({ isActive }) => (
                  <>
                    <span className="text-lg w-5 text-center shrink-0">{icon}</span>
                    <span>{label}</span>
                  </>
                )}
              </NavLink>
            ))
          ) : (
            <div className="px-3 py-8 text-center space-y-2">
              <NavLink to="/login" onClick={onClose}
                className="flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl bg-gray-900 text-white text-sm font-bold hover:opacity-80 transition-opacity">
                🔐 Đăng nhập
              </NavLink>
              <NavLink to="/register" onClick={onClose}
                className="flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl border text-sm font-bold sidebar-nav-item">
                ✨ Đăng ký miễn phí
              </NavLink>
            </div>
          )}
        </nav>

        <div className="mx-4 h-px sidebar-divider shrink-0" />

        {/* Bottom: templates + theme toggle + logout */}
        <div className="px-4 py-3 space-y-0.5 shrink-0">
          <NavLink
            to="/templates"
            onClick={onClose}
            className={({ isActive }) => `sidebar-nav-item ${isActive ? 'active' : ''}`}
          >
            <span className="text-lg w-5 text-center shrink-0">🗂️</span>
            <span>Templates</span>
          </NavLink>

          {/* Theme toggle */}
          <ThemeToggle className="w-full" />

          {isAuth && (
            <button
              onClick={() => { onClose(); onLogout(); }}
              className="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-medium text-red-500 hover:bg-red-500/10 transition-all"
            >
              <span className="text-lg w-5 text-center shrink-0">↩</span>
              <span>Đăng xuất</span>
            </button>
          )}
        </div>
      </aside>
    </>
  );
};
