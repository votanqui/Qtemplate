// ─────────────────────────────────────────────────────────
// Layout.jsx — Main app shell
// ─────────────────────────────────────────────────────────
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { DesktopSidebar } from './DesktopSidebar';
import { MobileSidebar } from './MobileSidebar';
import { BottomNav } from './BottomNav';

export const Layout = ({ children }) => {
  const { user, logout, isAuth } = useAuth();
  const navigate = useNavigate();
  const [drawerOpen, setDrawerOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <div className="flex min-h-screen page-root">

      {/* ── Desktop sidebar (lg+) ── */}
      <DesktopSidebar user={user} isAuth={isAuth} onLogout={handleLogout} />

      {/* ── Mobile drawer ── */}
      <MobileSidebar
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        user={user}
        isAuth={isAuth}
        onLogout={handleLogout}
      />

      {/* ── Main ── */}
      <div className="flex-1 flex flex-col min-w-0">

        {/* Mobile top bar */}
        <header className="lg:hidden sticky top-0 z-20 flex items-center justify-between px-4 h-14 border-b shadow-sm topbar-root">
          <button
            onClick={() => setDrawerOpen(true)}
            className="w-9 h-9 flex items-center justify-center topbar-btn"
            aria-label="Mở menu"
          >
            <svg width="18" height="14" viewBox="0 0 18 14" fill="none">
              <path d="M0 1h18M0 7h12M0 13h18" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
            </svg>
          </button>

          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-gray-900 flex items-center justify-center text-white font-black text-xs font-mono">
              Q
            </div>
            <span className="font-black text-base tracking-tight topbar-title">Qtemplate</span>
          </div>

          <div className="w-9 h-9 flex items-center justify-center">
            {isAuth ? (
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-violet-500 to-pink-500 flex items-center justify-center text-white font-bold text-xs shadow-sm">
                {user?.fullName?.[0]?.toUpperCase() || 'U'}
              </div>
            ) : <div className="w-9" />}
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-4 lg:p-8 max-w-6xl mx-auto w-full pb-20 lg:pb-8">
          {children}
        </main>
      </div>

      {/* ── Mobile bottom nav ── */}
      <BottomNav isAuth={isAuth} onLogout={handleLogout} />
    </div>
  );
};
