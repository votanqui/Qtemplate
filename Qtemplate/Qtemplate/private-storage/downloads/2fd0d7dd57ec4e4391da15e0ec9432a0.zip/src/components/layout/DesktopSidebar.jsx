// ─────────────────────────────────────────────────────────
// DesktopSidebar.jsx — desktop only, with theme toggle
// ─────────────────────────────────────────────────────────
import { NavLink } from 'react-router-dom';
import { SIDEBAR_SECTIONS } from './navConfig';
import { ThemeToggle } from './ThemeToggle';

const NavItem = ({ path, icon, label }) => (
  <NavLink
    to={path}
    className={({ isActive }) =>
      `sidebar-nav-item ${isActive ? 'active' : ''}`
    }
  >
    {({ isActive }) => (
      <>
        <span className={`text-sm w-4 text-center shrink-0 transition-transform duration-150 ${!isActive ? 'group-hover:scale-110' : ''}`}>
          {icon}
        </span>
        <span className="truncate">{label}</span>
        {isActive && <div className="ml-auto w-1 h-3.5 rounded-full bg-white/25 shrink-0" />}
      </>
    )}
  </NavLink>
);

export const DesktopSidebar = ({ user, isAuth, onLogout }) => {
  const sections = isAuth
    ? SIDEBAR_SECTIONS
    : SIDEBAR_SECTIONS.filter(s => s.key === 'main');

  return (
    <aside className="
      hidden lg:flex flex-col
      w-56 shrink-0
      h-screen sticky top-0
      border-r sidebar-root
      overflow-hidden
    ">

      {/* ── Logo ── */}
      <div className="px-5 pt-5 pb-4 shrink-0">
        <NavLink to="/" className="flex items-center gap-2.5 group">
          <div className="w-8 h-8 rounded-xl bg-gray-900 flex items-center justify-center text-white font-black text-sm font-mono shadow-md group-hover:opacity-80 transition-opacity">
            Q
          </div>
          <div className="leading-none">
            <div className="font-black text-base tracking-tight sidebar-text-strong">Qtemplate</div>
            <div className="text-[9px] font-semibold tracking-widest uppercase mt-0.5 sidebar-text-muted">Marketplace</div>
          </div>
        </NavLink>
      </div>

      <div className="mx-4 h-px sidebar-divider shrink-0" />

      {/* ── User card ── */}
      {isAuth && (
        <div className="px-3 pt-3 pb-2 shrink-0">
          <div className="flex items-center gap-2.5 px-2.5 py-2 rounded-xl border sidebar-user-card">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-violet-500 to-pink-500 flex items-center justify-center text-white font-bold text-xs shadow-sm shrink-0">
              {user?.fullName?.[0]?.toUpperCase() || 'U'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold truncate leading-tight sidebar-text-strong">{user?.fullName || 'Người dùng'}</p>
              <p className="text-[10px] capitalize truncate sidebar-text-muted">{user?.role || 'Member'}</p>
            </div>
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0 ring-1 ring-white/20" />
          </div>
        </div>
      )}

      {/* ── Nav sections ── */}
      <nav className="flex-1 overflow-y-auto min-h-0 px-3 py-2 space-y-4">
        {sections.map(section => (
          <div key={section.key}>
            <p className="px-3 mb-1 text-[10px] font-bold uppercase tracking-widest sidebar-label">
              {section.label}
            </p>
            <div className="space-y-0.5">
              {section.items.map(item => (
                <NavItem key={item.path} {...item} />
              ))}
            </div>
          </div>
        ))}

        {/* Guest CTA */}
        {!isAuth && (
          <div className="px-1 pt-2 space-y-1.5">
            <NavLink to="/login"
              className="flex items-center justify-center gap-1.5 w-full px-4 py-2 rounded-xl bg-gray-900 text-white text-xs font-bold hover:opacity-80 transition-opacity">
              🔐 Đăng nhập
            </NavLink>
            <NavLink to="/register"
              className="flex items-center justify-center gap-1.5 w-full px-4 py-2 rounded-xl border text-xs font-bold transition-colors sidebar-nav-item">
              ✨ Đăng ký
            </NavLink>
          </div>
        )}
      </nav>

      <div className="mx-4 h-px sidebar-divider shrink-0" />

      {/* ── Theme toggle ── */}
      <div className="px-3 pt-3 pb-1 shrink-0">
        <ThemeToggle className="w-full justify-start" />
      </div>

      {/* ── Logout ── */}
      {isAuth && (
        <div className="px-3 pb-3 shrink-0">
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm font-medium text-red-500 hover:bg-red-500/10 transition-all group"
          >
            <span className="text-sm w-4 text-center shrink-0 group-hover:scale-110 transition-transform">↩</span>
            <span>Đăng xuất</span>
          </button>
        </div>
      )}
    </aside>
  );
};
