// ─────────────────────────────────────────────────────────
// BottomNav.jsx — mobile bottom nav with theme toggle
// ─────────────────────────────────────────────────────────
import { NavLink } from 'react-router-dom';
import { BOTTOM_NAV_AUTH, BOTTOM_NAV_GUEST } from './navConfig';
import { useTheme } from '../../context/ThemeContext';

export const BottomNav = ({ isAuth, onLogout }) => {
  const items = isAuth ? BOTTOM_NAV_AUTH : BOTTOM_NAV_GUEST;
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === 'dark';

  return (
    <nav
      className="lg:hidden fixed bottom-0 left-0 right-0 z-40 border-t bottom-nav-root"
      style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
    >
      <div className="flex items-stretch h-16">

        {items.map(({ path, icon, label }) => (
          <NavLink
            key={path}
            to={path}
            className={({ isActive }) =>
              `relative flex-1 flex flex-col items-center justify-center gap-0.5 transition-all duration-150 bottom-nav-item ${isActive ? 'active' : ''}`
            }
          >
            {({ isActive }) => (
              <>
                {isActive && (
                  <span className="absolute top-0 left-1/2 -translate-x-1/2 w-6 h-0.5 rounded-b-full bottom-nav-indicator" />
                )}
                <span className={`text-xl transition-all duration-150 ${isActive ? 'scale-110' : 'scale-100'}`}>
                  {icon}
                </span>
                <span className="text-[9px] font-bold tracking-wide uppercase leading-none">
                  {label}
                </span>
              </>
            )}
          </NavLink>
        ))}

        {/* Theme toggle */}
        <button
          onClick={toggleTheme}
          aria-label="Đổi theme"
          className="relative flex-1 flex flex-col items-center justify-center gap-0.5 transition-all duration-150 bottom-nav-item"
        >
          <span className="text-xl">{isDark ? '☀️' : '🌙'}</span>
          <span className="text-[9px] font-bold tracking-wide uppercase leading-none">
            {isDark ? 'Sáng' : 'Tối'}
          </span>
        </button>

        {/* Logout — auth only */}
        {isAuth && (
          <button
            onClick={onLogout}
            className="relative flex-1 flex flex-col items-center justify-center gap-0.5 text-red-400 active:text-red-600 transition-all"
          >
            <span className="text-xl">↩</span>
            <span className="text-[9px] font-bold tracking-wide uppercase leading-none">Thoát</span>
          </button>
        )}
      </div>
    </nav>
  );
};
