import { useTheme } from '../../context/ThemeContext';

export const ThemeToggle = ({ className = '' }) => {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === 'dark';

  return (
    <button
      onClick={toggleTheme}
      aria-label={isDark ? 'Chuyển sang sáng' : 'Chuyển sang tối'}
      className={`
        relative flex items-center gap-2 px-3 py-2 rounded-xl
        transition-all duration-200 text-sm font-medium
        theme-toggle-btn
        ${className}
      `}
    >
      {/* Track */}
      <div className={`
        relative w-10 h-5 rounded-full transition-colors duration-300 shrink-0
        ${isDark ? 'bg-brand-500' : 'bg-gray-300'}
      `}>
        {/* Thumb */}
        <div className={`
          absolute top-0.5 w-4 h-4 rounded-full shadow-sm
          transition-all duration-300 flex items-center justify-center text-[9px]
          ${isDark ? 'translate-x-5 bg-white' : 'translate-x-0.5 bg-white'}
        `}>
          {isDark ? '🌙' : '☀️'}
        </div>
      </div>
      <span className="theme-toggle-label">
        {isDark ? 'Tối' : 'Sáng'}
      </span>
    </button>
  );
};
