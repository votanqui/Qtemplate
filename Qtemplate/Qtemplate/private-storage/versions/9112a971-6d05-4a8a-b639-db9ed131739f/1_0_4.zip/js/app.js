/* ============================================================
   LUXE STORE — Main App JavaScript
   js/app.js
   ============================================================ */

/* ── Router ── */
const Router = (() => {
  function navigate(pageId) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const target = document.getElementById(pageId);
    if (target) target.classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Update active nav link
    document.querySelectorAll('.nav-links a').forEach(a => {
      a.classList.toggle('active', a.dataset.page === pageId);
    });
  }

  // Bind all [data-page] links and buttons
  function init() {
    document.addEventListener('click', e => {
      const el = e.target.closest('[data-page]');
      if (el) {
        e.preventDefault();
        navigate(el.dataset.page);
      }
    });
  }

  return { navigate, init };
})();

/* ── Toast ── */
const Toast = (() => {
  let timer = null;

  function show(message) {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = message;
    el.classList.add('show');
    clearTimeout(timer);
    timer = setTimeout(() => el.classList.remove('show'), 2800);
  }

  return { show };
})();

/* ── Cart State ── */
const Cart = (() => {
  let count = 3;

  function updateBadge() {
    const badge = document.querySelector('.cart-badge');
    if (badge) badge.textContent = count;
  }

  function add() {
    count++;
    updateBadge();
    Toast.show('🛒 Đã thêm vào giỏ hàng!');
  }

  return { add, updateBadge };
})();

/* ── Wishlist ── */
const Wishlist = (() => {
  function add() {
    Toast.show('♡ Đã thêm vào yêu thích!');
  }
  return { add };
})();

/* ── Qty Controls ── */
function initQtyControls() {
  document.querySelectorAll('.qty-control').forEach(ctrl => {
    const dec = ctrl.querySelector('[data-action="dec"]');
    const inc = ctrl.querySelector('[data-action="inc"]');
    const display = ctrl.querySelector('.qty-value');
    if (!display) return;

    let qty = parseInt(display.textContent) || 1;

    dec?.addEventListener('click', () => {
      if (qty > 1) { qty--; display.textContent = qty; }
    });
    inc?.addEventListener('click', () => {
      qty++;
      display.textContent = qty;
    });
  });
}

/* ── Color Swatches ── */
function initColorSwatches() {
  document.querySelectorAll('.color-options').forEach(group => {
    group.querySelectorAll('.color-swatch').forEach(swatch => {
      swatch.addEventListener('click', () => {
        group.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('active'));
        swatch.classList.add('active');

        // Update label if present
        const label = swatch.closest('.option-group')?.querySelector('.selected-color');
        if (label) label.textContent = swatch.dataset.color || '';
      });
    });
  });
}

/* ── Size Buttons ── */
function initSizeButtons() {
  document.querySelectorAll('.size-options').forEach(group => {
    group.querySelectorAll('.size-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        group.querySelectorAll('.size-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      });
    });
  });
}

/* ── Tabs ── */
function initTabs() {
  document.querySelectorAll('.tab-headers').forEach(headers => {
    const tabGroup = headers.closest('.detail-tabs');
    if (!tabGroup) return;

    headers.querySelectorAll('.tab-header').forEach((header, i) => {
      header.addEventListener('click', () => {
        headers.querySelectorAll('.tab-header').forEach(h => h.classList.remove('active'));
        header.classList.add('active');

        tabGroup.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
        const panels = tabGroup.querySelectorAll('.tab-panel');
        if (panels[i]) panels[i].classList.add('active');
      });
    });
  });
}

/* ── Thumbnails ── */
function initThumbs() {
  document.querySelectorAll('.thumb-row').forEach(row => {
    row.querySelectorAll('.thumb').forEach(thumb => {
      thumb.addEventListener('click', () => {
        row.querySelectorAll('.thumb').forEach(t => t.classList.remove('active'));
        thumb.classList.add('active');
        // In a real app: swap main image src here
      });
    });
  });
}

/* ── Payment Options ── */
function initPaymentOptions() {
  document.querySelectorAll('.payment-options').forEach(group => {
    group.querySelectorAll('.payment-option').forEach(opt => {
      opt.addEventListener('click', () => {
        group.querySelectorAll('.payment-option').forEach(o => o.classList.remove('selected'));
        opt.classList.add('selected');
        const radio = opt.querySelector('input[type="radio"]');
        if (radio) radio.checked = true;
      });
    });
  });
}

/* ── Remove Cart Item ── */
function initRemoveItems() {
  document.querySelectorAll('.remove-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const row = btn.closest('tr');
      if (row) {
        row.style.opacity = '0';
        row.style.transition = 'opacity 0.3s';
        setTimeout(() => row.remove(), 300);
        Toast.show('🗑 Đã xóa sản phẩm khỏi giỏ');
      }
    });
  });
}

/* ── Wishlist Remove ── */
function initWishlistRemove() {
  document.querySelectorAll('.wishlist-remove').forEach(btn => {
    btn.addEventListener('click', () => {
      const card = btn.closest('.wishlist-card');
      if (card) {
        card.style.opacity = '0';
        card.style.transition = 'opacity 0.3s';
        setTimeout(() => card.remove(), 300);
        Toast.show('✕ Đã xóa khỏi yêu thích');
      }
    });
  });
}

/* ── Newsletter Form ── */
function initNewsletter() {
  const form = document.querySelector('.newsletter-form');
  const btn = form?.querySelector('button');
  btn?.addEventListener('click', () => {
    const input = form.querySelector('input');
    if (input?.value) {
      Toast.show('✉ Đăng ký thành công!');
      input.value = '';
    }
  });
}

/* ── Checkout Submit ── */
function initCheckout() {
  const submitBtn = document.querySelector('.checkout-submit');
  submitBtn?.addEventListener('click', () => {
    Toast.show('✅ Đặt hàng thành công! Cảm ơn bạn.');
  });
}

/* ── Init All ── */
document.addEventListener('DOMContentLoaded', () => {
  Router.init();
  Cart.updateBadge();
  initQtyControls();
  initColorSwatches();
  initSizeButtons();
  initTabs();
  initThumbs();
  initPaymentOptions();
  initRemoveItems();
  initWishlistRemove();
  initNewsletter();
  initCheckout();
});
