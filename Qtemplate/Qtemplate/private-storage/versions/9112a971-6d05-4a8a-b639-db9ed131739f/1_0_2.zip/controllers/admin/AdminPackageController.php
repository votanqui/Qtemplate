<?php
// controllers/admin/AdminPackageController.php

class AdminPackageController {
    private $packageService;
    private $authService;
    
    public function __construct() {
        $this->packageService = new AdminPackageService();
        $this->authService = new AuthService();
    }
    
    /**
     * GET /admin/packages?page=1&limit=20&search=&status=all
     */
    public function getPackages() {
        $this->requireAdmin();
        
        $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
        $limit = isset($_GET['limit']) ? min(100, max(1, intval($_GET['limit']))) : 20;
        $search = $_GET['search'] ?? '';
        $status = $_GET['status'] ?? 'all'; // all, active, inactive
        
        $result = $this->packageService->getPackages($page, $limit, $search, $status);
        
        Response::success($result, 'Lấy danh sách gói nạp thành công');
    }
    
    /**
     * GET /admin/packages/{id}
     */
    public function getPackageDetail($id) {
        $this->requireAdmin();
        
        if (empty($id) || !is_numeric($id)) {
            Response::error('ID gói nạp không hợp lệ', 400);
        }
        
        $result = $this->packageService->getPackageDetail($id);
        
        if (!$result) {
            Response::notFound('Không tìm thấy gói nạp');
        }
        
        Response::success($result, 'Lấy thông tin gói nạp thành công');
    }
    
    /**
     * POST /admin/packages
     * Body: {
     *   "package_code": "GOI1",
     *   "package_name": "Gói Tân Thủ",
     *   "price": 50000,
     *   "reward_xu": 25000,
     *   "reward_luong": 2500,
     *   "reward_luong_khoa": 1250,
     *   "items": "DB:685:1:-1,GEM:249:2000:-1",
     *   "description": "Gói nạp dành cho tân thủ",
     *   "image_url": "https://example.com/image.png",
     *   "display_order": 1,
     *   "is_active": 1,
     *   "is_hot": 0,
     *   "discount_percent": 0
     * }
     */
    public function createPackage() {
        $this->requireAdmin();
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            Response::error('Dữ liệu JSON không hợp lệ', 400);
        }
        
        $result = $this->packageService->createPackage($input);
        
        if (!$result['success']) {
            Response::validationError($result['errors'] ?? ['message' => $result['message']]);
        }
        
        Response::success($result['package'], 'Tạo gói nạp thành công', 201);
    }
    
    /**
     * PUT /admin/packages/{id}
     * Body: { ...update_data }
     */
    public function updatePackage($id) {
        $this->requireAdmin();
        
        if (empty($id) || !is_numeric($id)) {
            Response::error('ID gói nạp không hợp lệ', 400);
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            Response::error('Dữ liệu JSON không hợp lệ', 400);
        }
        
        $result = $this->packageService->updatePackage($id, $input);
        
        if (!$result['success']) {
            Response::error($result['message'], 400);
        }
        
        Response::success($result['package'], 'Cập nhật gói nạp thành công');
    }
    
    /**
     * DELETE /admin/packages/{id}
     */
    public function deletePackage($id) {
        $this->requireAdmin();
        
        if (empty($id) || !is_numeric($id)) {
            Response::error('ID gói nạp không hợp lệ', 400);
        }
        
        $result = $this->packageService->deletePackage($id);
        
        if (!$result['success']) {
            Response::error($result['message'], 400);
        }
        
        Response::success(null, 'Xóa gói nạp thành công');
    }
    
    /**
     * GET /admin/packages/{id}/logs?page=1&limit=20&status=
     */
    public function getPackagePurchaseLog($id) {
        $this->requireAdmin();
        
        if (empty($id) || !is_numeric($id)) {
            Response::error('ID gói nạp không hợp lệ', 400);
        }
        
        $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
        $limit = isset($_GET['limit']) ? min(100, max(1, intval($_GET['limit']))) : 20;
        $status = $_GET['status'] ?? null; // null, pending, paid, completed, failed, cancelled
        
        $result = $this->packageService->getPackagePurchaseLog($id, $page, $limit, $status);
        
        if (!$result) {
            Response::notFound('Không tìm thấy gói nạp');
        }
        
        Response::success($result, 'Lấy lịch sử mua gói thành công');
    }
    
    /**
     * GET /admin/packages/stats
     */
    public function getPackageStats() {
        $this->requireAdmin();
        
        $result = $this->packageService->getPackageStats();
        
        Response::success($result, 'Lấy thống kê gói nạp thành công');
    }
    
    /**
     * GET /admin/packages/{id}/buyers?server_id=1&page=1&limit=20
     */
    public function getPackageBuyers($id) {
        $this->requireAdmin();
        
        if (empty($id) || !is_numeric($id)) {
            Response::error('ID gói nạp không hợp lệ', 400);
        }
        
        $serverId = isset($_GET['server_id']) && is_numeric($_GET['server_id']) ? intval($_GET['server_id']) : null;
        $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
        $limit = isset($_GET['limit']) ? min(100, max(1, intval($_GET['limit']))) : 20;
        
        $result = $this->packageService->getPackageBuyers($id, $serverId, $page, $limit);
        
        Response::success($result, 'Lấy danh sách người mua thành công');
    }
    
    /**
     * GET /admin/packages/export?search=&status=all
     */
    public function exportPackages() {
        $this->requireAdmin();
        
        $search = $_GET['search'] ?? '';
        $status = $_GET['status'] ?? 'all';
        
        $result = $this->packageService->exportPackages($search, $status);
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="packages_export_' . date('Y-m-d_His') . '.csv"');
        
        echo "\xEF\xBB\xBF";
        echo $result;
        exit;
    }
    
    /**
     * POST /admin/packages/bulk-delete
     * Body: { "package_ids": [1, 2, 3] }
     */
    public function bulkDelete() {
        $this->requireAdmin();
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input || empty($input['package_ids'])) {
            Response::error('Dữ liệu không hợp lệ', 400);
        }
        
        $result = $this->packageService->bulkDelete($input['package_ids']);
        
        if (!$result['success']) {
            Response::error($result['message'], 400);
        }
        
        Response::success([
            'deleted_count' => $result['deleted_count']
        ], 'Xóa hàng loạt thành công');
    }
    
    /**
     * POST /admin/packages/{id}/toggle-active
     */
    public function toggleActive($id) {
        $this->requireAdmin();
        
        if (empty($id) || !is_numeric($id)) {
            Response::error('ID gói nạp không hợp lệ', 400);
        }
        
        $result = $this->packageService->toggleActive($id);
        
        if (!$result['success']) {
            Response::error($result['message'], 400);
        }
        
        Response::success($result['package'], 'Cập nhật trạng thái thành công');
    }
    
    /**
     * POST /admin/packages/{id}/toggle-hot
     */
    public function toggleHot($id) {
        $this->requireAdmin();
        
        if (empty($id) || !is_numeric($id)) {
            Response::error('ID gói nạp không hợp lệ', 400);
        }
        
        $result = $this->packageService->toggleHot($id);
        
        if (!$result['success']) {
            Response::error($result['message'], 400);
        }
        
        Response::success($result['package'], 'Cập nhật trạng thái Hot thành công');
    }
    
    // Helper methods
    
    private function requireAdmin() {
        $token = $this->getBearerToken();
        
        if (!$token) {
            Response::unauthorized('Yêu cầu mã truy cập');
        }
        
        $userId = $this->authService->validateAccessToken($token);
        
        if (!$userId) {
            Response::unauthorized('Mã không hợp lệ hoặc đã hết hạn');
        }
        
        if (!AdminMiddleware::isAdmin($userId)) {
            Response::forbidden('Bạn không có quyền truy cập');
        }
        
        return $userId;
    }
    
    private function getBearerToken() {
        $headers = getallheaders();
        
        if (isset($headers['Authorization'])) {
            $matches = [];
            if (preg_match('/Bearer\s+(.*)$/i', $headers['Authorization'], $matches)) {
                return $matches[1];
            }
        }
        
        return null;
    }
}