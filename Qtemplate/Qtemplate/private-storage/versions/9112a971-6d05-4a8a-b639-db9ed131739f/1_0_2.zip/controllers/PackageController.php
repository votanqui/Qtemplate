<?php
// controllers/PackageController.php

require_once __DIR__ . '/../services/PackageService.php';
require_once __DIR__ . '/../helpers/Response.php';

class PackageController {
    private $packageService;
    
    public function __construct() {
        $this->packageService = new PackageService();
    }
    
    /**
     * Lấy danh sách tất cả gói nạp
     * GET /api/packages
     */
    public function getAllPackages() {
        try {
            $result = $this->packageService->getAllPackages();
            
            if ($result['success']) {
                Response::success($result['data'], 'Lấy danh sách gói nạp thành công');
            } else {
                Response::error($result['message'], 400);
            }
            
        } catch (Exception $e) {
            error_log("Get all packages error: " . $e->getMessage());
            Response::error('Lỗi hệ thống: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * Lấy thông tin chi tiết 1 gói
     * GET /api/packages/:id
     */
    public function getPackageById() {
        try {
            $packageId = $_GET['id'] ?? null;
            
            if (!$packageId) {
                Response::error('Thiếu tham số id', 400);
            }
            
            $result = $this->packageService->getPackageById((int)$packageId);
            
            if ($result['success']) {
                Response::success($result['data'], 'Lấy thông tin gói thành công');
            } else {
                Response::error($result['message'], 400);
            }
            
        } catch (Exception $e) {
            error_log("Get package error: " . $e->getMessage());
            Response::error('Lỗi hệ thống: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * Tạo đơn hàng mua gói
     * POST /api/packages/purchase
     * Body: {
     *   "player_name": "TenNhanVat",
     *   "server_id": 1,
     *   "package_id": 1
     * }
     */
    public function createPurchaseOrder() {
        try {
            $input = json_decode(file_get_contents('php://input'), true);
            
            if (!$input) {
                Response::error('Invalid request body', 400);
            }
            
            $playerName = $input['player_name'] ?? null;
            $serverId = $input['server_id'] ?? 1;
            $packageId = $input['package_id'] ?? null;
            
            if (!$playerName) {
                Response::error('Thiếu tham số player_name', 400);
            }
            
            if (!$packageId) {
                Response::error('Thiếu tham số package_id', 400);
            }
            
            $result = $this->packageService->createPackageOrder(
                $playerName,
                (int)$serverId,
                (int)$packageId
            );
            
            if ($result['success']) {
                Response::success($result['data'], 'Tạo đơn hàng thành công');
            } else {
                Response::error($result['message'], 400);
            }
            
        } catch (Exception $e) {
            error_log("Create purchase order error: " . $e->getMessage());
            Response::error('Lỗi hệ thống: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * Lấy lịch sử mua gói
     * GET /api/packages/history?player_name=xxx&server_id=1&page=1&limit=10
     */
    public function getPurchaseHistory() {
        try {
            $playerName = $_GET['player_name'] ?? null;
            $serverId = isset($_GET['server_id']) ? (int)$_GET['server_id'] : null;
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
            
            if (!$playerName) {
                Response::error('Thiếu tham số player_name', 400);
            }
            
            $result = $this->packageService->getPurchaseHistory(
                $playerName,
                $serverId,
                $page,
                $limit
            );
            
            if ($result['success']) {
                Response::success($result['data'], 'Lấy lịch sử thành công');
            } else {
                Response::error($result['message'], 400);
            }
            
        } catch (Exception $e) {
            error_log("Get purchase history error: " . $e->getMessage());
            Response::error('Lỗi hệ thống: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * Kiểm tra trạng thái đơn hàng
     * GET /api/packages/verify?order_id=PKG_xxx
     */
    public function verifyOrder() {
        try {
            $orderId = $_GET['order_id'] ?? null;
            
            if (!$orderId) {
                Response::error('Thiếu tham số order_id', 400);
            }
            
            // Kiểm tra trong package_orders
            $stmt = Database::getInstance()->getConnection()->prepare("
                SELECT 
                    order_id,
                    package_name,
                    price,
                    status,
                    updated_at,
                    reward_xu,
                    reward_luong,
                    reward_luong_khoa
                FROM package_orders 
                WHERE order_id = ?
                LIMIT 1
            ");
            $stmt->execute([$orderId]);
            $order = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$order) {
                Response::error('Đơn hàng không tồn tại', 404);
            }
            
            $statusMessages = [
                'pending' => 'Chờ thanh toán',
                'paid' => 'Đã thanh toán, đang xử lý',
                'completed' => 'Hoàn thành',
                'failed' => 'Thất bại',
                'cancelled' => 'Đã hủy'
            ];
            
            Response::success([
                'order_id' => $order['order_id'],
                'package_name' => $order['package_name'],
                'price' => (float)$order['price'],
                'status' => $order['status'],
                'status_message' => $statusMessages[$order['status']] ?? 'Không xác định',
                'rewards' => [
                    'xu' => (int)$order['reward_xu'],
                    'luong' => (int)$order['reward_luong'],
                    'luong_khoa' => (int)$order['reward_luong_khoa']
                ],
                'last_update' => $order['updated_at']
            ], 'Lấy trạng thái thành công');
            
        } catch (Exception $e) {
            error_log("Verify order error: " . $e->getMessage());
            Response::error('Lỗi hệ thống: ' . $e->getMessage(), 500);
        }
    }
    
    /**
     * Hủy đơn hàng pending
     * POST /api/packages/cancel
     * Body: {
     *   "order_id": "PKG_xxx",
     *   "player_name": "TenNhanVat"
     * }
     */
    public function cancelOrder() {
        try {
            $input = json_decode(file_get_contents('php://input'), true);
            
            if (!$input) {
                Response::error('Invalid request body', 400);
            }
            
            $orderId = $input['order_id'] ?? null;
            $playerName = $input['player_name'] ?? null;
            
            if (!$orderId) {
                Response::error('Thiếu tham số order_id', 400);
            }
            
            $db = Database::getInstance()->getConnection();
            
            // Kiểm tra order
            $sql = "SELECT * FROM package_orders WHERE order_id = ?";
            $params = [$orderId];
            
            if ($playerName) {
                $sql .= " AND player_name = ?";
                $params[] = $playerName;
            }
            
            $sql .= " AND status = 'pending' LIMIT 1";
            
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            $order = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$order) {
                Response::error('Đơn hàng không tồn tại hoặc không thể hủy', 404);
            }
            
            // Cập nhật status
            $updateStmt = $db->prepare("
                UPDATE package_orders 
                SET status = 'cancelled',
                    updated_at = NOW()
                WHERE order_id = ?
            ");
            $updateStmt->execute([$orderId]);
            
            Response::success([
                'order_id' => $orderId,
                'cancelled_at' => date('Y-m-d H:i:s')
            ], 'Hủy đơn hàng thành công');
            
        } catch (Exception $e) {
            error_log("Cancel order error: " . $e->getMessage());
            Response::error('Lỗi hệ thống: ' . $e->getMessage(), 500);
        }
    }
}