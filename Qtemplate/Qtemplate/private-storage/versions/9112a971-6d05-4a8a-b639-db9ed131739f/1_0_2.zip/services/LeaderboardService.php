<?php
// services/LeaderboardService.php

class LeaderboardService {
    private $accountDb;
    private $gameDbs = [];
    
    public function __construct() {
        $this->accountDb = Database::getInstance()->getConnection();
    }
    
    /**
     * Lấy kết nối game database theo server_id
     */
    private function getGameDb($serverId = null) {
        if ($serverId === null) {
            $serverId = Config::DEFAULT_SERVER_ID;
        }
        
        if (!isset($this->gameDbs[$serverId])) {
            $dbInstance = Database::getGameInstance($serverId);
            $this->gameDbs[$serverId] = $dbInstance->getConnection();
        }
        
        return $this->gameDbs[$serverId];
    }
    public function getEventResults($eventId, $limit = 10, $serverId = null) {
    try {
        // Kiểm tra event có tồn tại và đã kết thúc chưa
        $stmt = $this->accountDb->prepare("
            SELECT * FROM events 
            WHERE id = ? AND is_finished = 1
        ");
        $stmt->execute([$eventId]);
        $event = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$event) {
            return [
                'success' => false,
                'message' => 'Event không tồn tại hoặc chưa được chốt kết quả'
            ];
        }
        
        // Lấy kết quả từ event_results
        $query = "
            SELECT 
                rank,
                user_id,
                player_name,
                server_id,
                total_amount,
                total_xu,
                total_luong,
                total_luong_khoa,
                total_recharge,
                level,
                xp,
                boss_kills,
                event_points,
                reward_description,
                is_claimed,
                claimed_at,
                saved_at
            FROM event_results
            WHERE event_id = ?
        ";
        
        $params = [$eventId];
        
        if ($serverId !== null) {
            $query .= " AND server_id = ?";
            $params[] = $serverId;
        }
        
        $query .= " ORDER BY rank ASC LIMIT ?";
        $params[] = $limit;
        
        $stmt = $this->accountDb->prepare($query);
        $stmt->execute($params);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $leaderboard = [];
        foreach ($results as $row) {
            $item = [
                'rank' => (int)$row['rank'],
                'reward' => $row['reward_description'],
                'is_claimed' => (bool)$row['is_claimed'],
                'claimed_at' => $row['claimed_at'],
                'saved_at' => $row['saved_at'],
                'rank_color' => $this->getRankColor($row['rank'])
            ];
            
            // Thêm fields theo event_type
            if ($event['event_type'] == 'recharge') {
                $item['username'] = $row['player_name'];
                $item['total_amount'] = (float)$row['total_amount'];
                $item['formatted_amount'] = number_format($row['total_amount'], 0, ',', '.') . ' VNĐ';
                $item['total_xu'] = (int)$row['total_xu'];
                $item['total_luong'] = (int)$row['total_luong'];
                $item['total_luong_khoa'] = (int)$row['total_luong_khoa'];
                $item['total_recharge'] = (int)$row['total_recharge'];
            } elseif ($event['event_type'] == 'level') {
                $item['charname'] = $row['player_name'];
                $item['xp'] = (int)$row['xp'];
                
                // TÍNH LẠI LEVEL TỪ XP thay vì dùng level đã lưu
                $levelData = $this->getLevelFromExp($item['xp']);
                $item['level'] = $levelData['level'];
                $item['exp_percentage'] = $levelData['percent'];
                $item['exp_current_level'] = $levelData['exp_current_level'];
                $item['exp_needed_next_level'] = $levelData['exp_needed_next_level'];
            } elseif ($event['event_type'] == 'boss') {
                $item['player'] = $row['player_name'];
                $item['boss_kills'] = (int)$row['boss_kills'];
            } elseif ($event['event_type'] == 'event') {
                $item['charname'] = $row['player_name'];
                $item['points'] = (int)$row['event_points'];
            }
            
            $leaderboard[] = $item;
        }
        
        return [
            'success' => true,
            'data' => [
                'title' => 'Kết Quả ' . $event['event_name'],
                'event_info' => [
                    'event_id' => $event['id'],
                    'event_name' => $event['event_name'],
                    'event_code' => $event['event_code'],
                    'event_type' => $event['event_type'],
                    'description' => $event['description'],
                    'start_time' => $event['start_time'],
                    'end_time' => $event['end_time'],
                    'finished_at' => $event['finished_at']
                ],
                'server_id' => $serverId,
                'total' => count($leaderboard),
                'leaderboard' => $leaderboard
            ]
        ];
        
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => 'Lỗi khi lấy kết quả event: ' . $e->getMessage()
        ];
    }
}
    /**
     * Lấy thông tin sự kiện đang active theo loại
     * Ưu tiên: 
     * 1. Event đang diễn ra (NOW BETWEEN start_time AND end_time)
     * 2. Event sắp diễn ra (is_active=1, is_finished=0)
     */
    private function getActiveEvent($eventType) {
        try {
            // Thử tìm event đang diễn ra
            $stmt = $this->accountDb->prepare("
                SELECT * FROM events 
                WHERE event_type = ? 
                AND is_active = 1 
                AND is_finished = 0
                AND NOW() BETWEEN start_time AND end_time
                ORDER BY start_time DESC
                LIMIT 1
            ");
            
            $stmt->execute([$eventType]);
            $event = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($event) {
                return $event;
            }
            
            // Nếu không có event đang diễn ra, lấy event active gần nhất
            $stmt = $this->accountDb->prepare("
                SELECT * FROM events 
                WHERE event_type = ? 
                AND is_active = 1 
                AND is_finished = 0
                ORDER BY ABS(TIMESTAMPDIFF(SECOND, NOW(), start_time)) ASC
                LIMIT 1
            ");
            
            $stmt->execute([$eventType]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
            
        } catch (Exception $e) {
            error_log("Error fetching active event: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Lấy phần thưởng từ bảng top_rewards_new theo event_id và top_type
     */
    private function getRewardsFromDB($eventId, $topType) {
        try {
            $stmt = $this->accountDb->prepare("
                SELECT rank, reward_description
                FROM top_rewards_new
                WHERE event_id = ? AND top_type = ?
                ORDER BY rank ASC
            ");
            
            $stmt->execute([$eventId, $topType]);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $rewards = [];
            foreach ($results as $row) {
                $rewards[(int)$row['rank']] = trim($row['reward_description']);
            }
            
            return $rewards;
        } catch (Exception $e) {
            error_log("Error fetching rewards for event {$eventId}, type {$topType}: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Lấy Level từ XP
     */
    private function getLevelFromExp($exp) {
    // Mảng expMain và expRequire giống như trong Java
    $expMain = array(0, 200, 800, 2000, 4000, 8000, 16000, 32000, 48000, 72000, 108000, 162000, 226800, 317520, 444528, 622339, 871274, 1132656, 1472452, 1914187, 2488443, 2986131, 3583357, 4300028, 5160033, 6192039, 7430446, 8916535, 10699842, 12839810, 15407772, 18489326, 22187191, 26624629, 31949554, 38339464, 46007356, 55208827, 66250592, 79500710, 95400852, 114481022, 137377226, 164852671, 197823205, 237387846, 284865415, 341838498, 410206197, 492247436, 590696923, 708836307, 850603568, 1020724281, 1224869137, 1469842964, 1763811556, 2116573867, 2539888640, 3047866368, 3657439641, 4388927569, 5266713082, 6320055698, 7584066837, 9100880204, 10921056244, 13105267492, 15726320990, 18871585188, 22645902225, 33968853337, 50953280005, 76429920007, 114644880010, 171967320015, 257950980022, 386926470033, 580389705049, 870584557573, 1305876836359, 1958815254538, 2938222881807, 4407334322710, 6611001484065, 9916502226098, 14874753339147, 22312130008720, 33468195013080, 50202292519620, 75303438779430);
    $expRequire = array(0, 200, 600, 1200, 2000, 4000, 8000, 16000, 16000, 24000, 36000, 54000, 64800, 90720, 127008, 177811, 248935, 261382, 339796, 441735, 574256, 497688, 597226, 716671, 860005, 1032006, 1238407, 1486089, 1783307, 2139968, 2567962, 3081554, 3697865, 4437438, 5324925, 6389910, 7667892, 9201471, 11041765, 13250118, 15900142, 19080170, 22896204, 27475445, 32970534, 39564641, 47477569, 56973083, 68367699, 82041239, 98449487, 118139384, 141767261, 170120713, 204144856, 244973827, 293968592, 352762311, 423314773, 507977728, 609573273, 731487928, 877785513, 1053342616, 1264011139, 1516813367, 1820176040, 2184211248, 2621053498, 3145264198, 3774317037, 11322951112, 16984426668, 25476640002, 38214960003, 57322440005, 85983660007, 128975490011, 193463235016, 290194852524, 435292278786, 652938418179, 979407627269, 1469111440903, 2203667161355, 3305500742033, 4958251113049, 7437376669573, 11156065004360, 16734097506540, 25101146259810, 0);

    $lv = 0;

    // Duyệt qua mảng expMain để xác định cấp độ dựa trên exp
    for ($i = 0; $i < count($expMain) && $exp >= $expMain[$i]; ++$i) {
        ++$lv;
    }

    $percent = 0;
    if ($lv >= count($expMain)) {
        $lv = count($expMain);
    } else {
        $percent = (int)(($exp - $expMain[$lv - 1]) * 1000 / $expRequire[$lv]);
    }
    
    // Format phần trăm thành dạng xx.xx%
    $formattedPercent = number_format($percent / 10, 2);

    return [
        'level' => $lv,
        'percent' => $formattedPercent,
        'exp_current_level' => $exp - $expMain[$lv - 1],
        'exp_needed_next_level' => $expRequire[$lv]
    ];
}
    /**
     * TOP 1: Xếp Hạng Level (Thời gian thực)
     */
public function getTopLevel($limit = 10, $serverId = null) {
    try {
        $gameDb = $this->getGameDb($serverId);
        
        // Lấy thông tin event đang active
        $activeEvent = $this->getActiveEvent('level');
        
        // THAY ĐỔI: Sắp xếp theo lastLv trước, sau đó theo xp nếu trùng level
        $stmt = $gameDb->prepare("
            SELECT charname, xp, lastLv 
            FROM tob_char 
            WHERE ban = '0' AND charname != 'chienthan' 
            ORDER BY lastLv DESC, xp DESC 
            LIMIT ?
        ");
        
        $stmt->execute([$limit]);
        $results = $stmt->fetchAll();
        
        // Lấy rewards từ event (nếu có)
        $rewards = [];
        if ($activeEvent) {
            $rewards = $this->getRewardsFromDB($activeEvent['id'], 'top_level');
        }
        
        $defaultReward = "không có thưởng";
        
        $leaderboard = [];
        foreach ($results as $index => $row) {
            $rank = $index + 1;
            $leaderboard[] = [
                'rank' => $rank,
                'charname' => $row['charname'],
                'level' => (int)$row['lastLv'],
                'xp' => (int)$row['xp'],
                'reward' => $rewards[$rank] ?? $defaultReward,
                'rank_color' => $this->getRankColor($rank)
            ];
        }
        
        return [
            'success' => true,
            'data' => [
                'title' => 'Danh Sách Xếp Hạng Level',
                'server_id' => $serverId,
                'total' => count($leaderboard),
                'event_info' => $activeEvent ? [
                    'event_id' => $activeEvent['id'],
                    'event_name' => $activeEvent['event_name'],
                    'event_code' => $activeEvent['event_code'],
                    'description' => $activeEvent['description'],
                    'start_time' => $activeEvent['start_time'],
                    'end_time' => $activeEvent['end_time'],
                    'time_remaining' => $this->getTimeRemaining($activeEvent['start_time'], $activeEvent['end_time']),
                    'is_ongoing' => $this->isEventOngoing($activeEvent['start_time'], $activeEvent['end_time'])
                ] : null,
                'leaderboard' => $leaderboard
            ]
        ];
        
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => 'Lỗi khi lấy bảng xếp hạng level: ' . $e->getMessage()
        ];
    }
}
    
    /**
     * TOP 2: Xếp Hạng Sự Kiện (Thời gian thực)
     */
    public function getTopEvent($limit = 10, $serverId = null) {
        try {
            $gameDb = $this->getGameDb($serverId);
            
            // Lấy thông tin event đang active
            $activeEvent = $this->getActiveEvent('event');
            
            $stmt = $gameDb->prepare("
                SELECT charname, point1 
                FROM tob_top_event 
                ORDER BY point1 DESC 
                LIMIT ?
            ");
            
            $stmt->execute([$limit]);
            $results = $stmt->fetchAll();
            
            // Lấy rewards từ event (nếu có)
            $rewards = [];
            if ($activeEvent) {
                $rewards = $this->getRewardsFromDB($activeEvent['id'], 'top_event');
            }
            
            $defaultReward = "Không có phần thưởng";
            
            $leaderboard = [];
            foreach ($results as $index => $row) {
                $rank = $index + 1;
                $leaderboard[] = [
                    'rank' => $rank,
                    'charname' => $row['charname'],
                    'points' => (int)$row['point1'],
                    'reward' => $rewards[$rank] ?? $defaultReward,
                    'rank_color' => $this->getRankColor($rank)
                ];
            }
            
            return [
                'success' => true,
                'data' => [
                    'title' => 'Danh Sách Xếp Hạng Sự Kiện',
                    'server_id' => $serverId,
                    'total' => count($leaderboard),
                    'event_info' => $activeEvent ? [
                        'event_id' => $activeEvent['id'],
                        'event_name' => $activeEvent['event_name'],
                        'event_code' => $activeEvent['event_code'],
                        'description' => $activeEvent['description'],
                        'start_time' => $activeEvent['start_time'],
                        'end_time' => $activeEvent['end_time'],
                        'time_remaining' => $this->getTimeRemaining($activeEvent['start_time'], $activeEvent['end_time']),
                        'is_ongoing' => $this->isEventOngoing($activeEvent['start_time'], $activeEvent['end_time'])
                    ] : null,
                    'leaderboard' => $leaderboard
                ]
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Lỗi khi lấy bảng xếp hạng sự kiện: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * TOP 3: Xếp Hạng Tích Lũy (Thời gian thực)
     */
/**
 * TOP 3: Xếp Hạng Tích Lũy (Thời gian thực)
 */
public function getTopRecharge($limit = 10, $serverId = null) {
    try {
        // Lấy thông tin event đang active
        $activeEvent = $this->getActiveEvent('recharge');
        
        $leaderboard = [];
        $rewards = [];
        
        // Nếu có event đang active, lấy từ event_recharge
        if ($activeEvent) {
            $rewards = $this->getRewardsFromDB($activeEvent['id'], 'top_nap');
            
            $query = "
                SELECT 
                    username,
                    total_amount,
                    total_xu,
                    total_luong,
                    total_luong_khoa,
                    total_recharge,
                    first_recharge_at,
                    last_recharge_at,
                    created_at
                FROM event_recharge 
                WHERE event_id = ? AND username != 'chienthan'
            ";
            
            $params = [$activeEvent['id']];
            
            // Lọc theo server_id nếu có
            if ($serverId !== null) {
                $query .= " AND server_id = ?";
                $params[] = $serverId;
            }
            
            // Sắp xếp: total_amount giảm dần, nếu bằng nhau thì first_recharge_at tăng dần (nạp trước lên top)
            $query .= " ORDER BY total_amount DESC, first_recharge_at ASC LIMIT ?";
            $params[] = $limit;
            
            $stmt = $this->accountDb->prepare($query);
            $stmt->execute($params);
            $results = $stmt->fetchAll();
            
        } else {
            // Không có event, lấy từ topnap (tổng nạp toàn thời gian)
            $query = "
                SELECT 
                    username,
                    total_amount,
                    total_xu,
                    total_luong,
                    total_luong_khoa,
                    total_recharge,
                    last_recharge_at,
                    created_at
                FROM topnap 
                WHERE username != 'chienthan'
            ";
            
            $params = [];
            
            // Lọc theo server_id nếu có
            if ($serverId !== null) {
                $query .= " AND server_id = ?";
                $params[] = $serverId;
            }
            
            // Sắp xếp: total_amount giảm dần, nếu bằng nhau thì created_at tăng dần (tạo trước lên top)
            $query .= " ORDER BY total_amount DESC, created_at ASC LIMIT ?";
            $params[] = $limit;
            
            $stmt = $this->accountDb->prepare($query);
            $stmt->execute($params);
            $results = $stmt->fetchAll();
        }
        
        $defaultReward = "không có thưởng";
        
        foreach ($results as $index => $row) {
            $rank = $index + 1;
            $item = [
                'rank' => $rank,
                'username' => $row['username'],
                'total_amount' => (float)$row['total_amount'],
                'total_xu' => (int)$row['total_xu'],
                'total_luong' => (int)$row['total_luong'],
                'total_luong_khoa' => (int)$row['total_luong_khoa'],
                'total_recharge' => (int)$row['total_recharge'],
                'formatted_amount' => number_format($row['total_amount'], 0, ',', '.') . ' VNĐ',
                'reward' => $rewards[$rank] ?? $defaultReward,
                'rank_color' => $this->getRankColor($rank)
            ];
            
            // Thêm thông tin thời gian tùy theo nguồn dữ liệu
            if ($activeEvent) {
                $item['first_recharge_at'] = $row['first_recharge_at'];
                $item['last_recharge_at'] = $row['last_recharge_at'];
                $item['created_at'] = $row['created_at'];
            } else {
                $item['last_recharge_at'] = $row['last_recharge_at'];
                $item['created_at'] = $row['created_at'];
            }
            
            $leaderboard[] = $item;
        }
        
        return [
            'success' => true,
            'data' => [
                'title' => $activeEvent ? 'Xếp Hạng Tích Lũy Event' : 'Xếp Hạng Tích Lũy Toàn Thời Gian',
                'server_id' => $serverId,
                'total' => count($leaderboard),
                'event_info' => $activeEvent ? [
                    'event_id' => $activeEvent['id'],
                    'event_name' => $activeEvent['event_name'],
                    'event_code' => $activeEvent['event_code'],
                    'description' => $activeEvent['description'],
                    'start_time' => $activeEvent['start_time'],
                    'end_time' => $activeEvent['end_time'],
                    'time_remaining' => $this->getTimeRemaining($activeEvent['start_time'], $activeEvent['end_time']),
                    'is_ongoing' => $this->isEventOngoing($activeEvent['start_time'], $activeEvent['end_time'])
                ] : null,
                'leaderboard' => $leaderboard
            ]
        ];
        
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => 'Lỗi khi lấy bảng xếp hạng tích lũy: ' . $e->getMessage()
        ];
    }
}
    
    /**
     * TOP 4: Xếp Hạng Săn Boss (Thời gian thực)
     */
    public function getTopBoss($limit = 10, $serverId = null) {
        try {
            $gameDb = $this->getGameDb($serverId);
            
            // Lấy thông tin event đang active
            $activeEvent = $this->getActiveEvent('boss');
            
            $stmt = $gameDb->prepare("
                SELECT player, win 
                FROM tob_sanboss 
                WHERE player != 'chienthan' 
                ORDER BY win DESC 
                LIMIT ?
            ");
            
            $stmt->execute([$limit]);
            $results = $stmt->fetchAll();
            
            // Lấy rewards từ event (nếu có)
            $rewards = [];
            if ($activeEvent) {
                $rewards = $this->getRewardsFromDB($activeEvent['id'], 'top_boss');
            }
            
            $defaultReward = "Không có phần thưởng";
            
            $leaderboard = [];
            foreach ($results as $index => $row) {
                $rank = $index + 1;
                $leaderboard[] = [
                    'rank' => $rank,
                    'player' => $row['player'],
                    'boss_kills' => (int)$row['win'],
                    'reward' => $rewards[$rank] ?? $defaultReward,
                    'rank_color' => $this->getRankColor($rank)
                ];
            }
            
            return [
                'success' => true,
                'data' => [
                    'title' => 'Danh Sách Xếp Hạng Săn Boss Tiên La',
                    'server_id' => $serverId,
                    'total' => count($leaderboard),
                    'event_info' => $activeEvent ? [
                        'event_id' => $activeEvent['id'],
                        'event_name' => $activeEvent['event_name'],
                        'event_code' => $activeEvent['event_code'],
                        'description' => $activeEvent['description'],
                        'start_time' => $activeEvent['start_time'],
                        'end_time' => $activeEvent['end_time'],
                        'time_remaining' => $this->getTimeRemaining($activeEvent['start_time'], $activeEvent['end_time']),
                        'is_ongoing' => $this->isEventOngoing($activeEvent['start_time'], $activeEvent['end_time'])
                    ] : null,
                    'leaderboard' => $leaderboard
                ]
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Lỗi khi lấy bảng xếp hạng săn boss: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Lấy kết quả event từ bảng event_results
     */
   public function getEventRechargeHistory($eventId, $limit = 10, $serverId = null) {
        try {
            // Kiểm tra event có tồn tại và đã kết thúc chưa
            $stmt = $this->accountDb->prepare("
                SELECT * FROM events 
                WHERE id = ? AND is_finished = 1
            ");
            $stmt->execute([$eventId]);
            $event = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$event) {
                return [
                    'success' => false,
                    'message' => 'Event không tồn tại hoặc chưa được chốt kết quả'
                ];
            }
            
            // Lấy kết quả từ event_results
            $query = "
                SELECT 
                    rank,
                    user_id,
                    player_name,
                    server_id,
                    total_amount,
                    total_xu,
                    total_luong,
                    total_luong_khoa,
                    total_recharge,
                    level,
                    xp,
                    boss_kills,
                    event_points,
                    reward_description,
                    is_claimed,
                    claimed_at,
                    saved_at
                FROM event_results
                WHERE event_id = ?
            ";
            
            $params = [$eventId];
            
            if ($serverId !== null) {
                $query .= " AND server_id = ?";
                $params[] = $serverId;
            }
            
            $query .= " ORDER BY rank ASC LIMIT ?";
            $params[] = $limit;
            
            $stmt = $this->accountDb->prepare($query);
            $stmt->execute($params);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $leaderboard = [];
            foreach ($results as $row) {
                $item = [
                    'rank' => (int)$row['rank'],
                    'username' => $row['player_name'],
                    'reward' => $row['reward_description'],
                    'is_claimed' => (bool)$row['is_claimed'],
                    'claimed_at' => $row['claimed_at'],
                    'saved_at' => $row['saved_at'],
                    'rank_color' => $this->getRankColor($row['rank'])
                ];
                
                // Thêm fields theo event_type
                if ($event['event_type'] == 'recharge') {
                    $item['total_amount'] = (float)$row['total_amount'];
                    $item['formatted_amount'] = number_format($row['total_amount'], 0, ',', '.') . ' VNĐ';
                    $item['total_xu'] = (int)$row['total_xu'];
                    $item['total_luong'] = (int)$row['total_luong'];
                    $item['total_luong_khoa'] = (int)$row['total_luong_khoa'];
                    $item['total_recharge'] = (int)$row['total_recharge'];
                } elseif ($event['event_type'] == 'level') {
                    $item['level'] = (int)$row['level'];
                    $item['xp'] = (int)$row['xp'];
                    $item['formatted_stat'] = "Level {$item['level']}";
                } elseif ($event['event_type'] == 'boss') {
                    $item['boss_kills'] = (int)$row['boss_kills'];
                    $item['formatted_stat'] = number_format($item['boss_kills']) . ' Boss';
                } elseif ($event['event_type'] == 'event') {
                    $item['event_points'] = (int)$row['event_points'];
                    $item['formatted_stat'] = number_format($item['event_points']) . ' điểm';
                }
                
                $leaderboard[] = $item;
            }
            
            return [
                'success' => true,
                'data' => [
                    'title' => 'Kết Quả ' . $event['event_name'],
                    'event_info' => [
                        'event_id' => $event['id'],
                        'event_name' => $event['event_name'],
                        'event_code' => $event['event_code'],
                        'event_type' => $event['event_type'],
                        'description' => $event['description'],
                        'start_time' => $event['start_time'],
                        'end_time' => $event['end_time'],
                        'finished_at' => $event['finished_at']
                    ],
                    'server_id' => $serverId,
                    'total' => count($leaderboard),
                    'leaderboard' => $leaderboard
                ]
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Lỗi khi lấy kết quả event: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Lấy danh sách các event đã kết thúc theo loại
     */
    public function getFinishedEvents($eventType = null) {
        try {
            $query = "
                SELECT 
                    id,
                    event_code,
                    event_name,
                    event_type,
                    description,
                    start_time,
                    end_time,
                    finished_at,
                    finished_by
                FROM events 
                WHERE is_finished = 1
            ";
            
            $params = [];
            
            if ($eventType !== null) {
                $query .= " AND event_type = ?";
                $params[] = $eventType;
            }
            
            $query .= " ORDER BY finished_at DESC";
            
            $stmt = $this->accountDb->prepare($query);
            $stmt->execute($params);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $events = [];
            foreach ($results as $row) {
                $events[] = [
                    'event_id' => (int)$row['id'],
                    'event_code' => $row['event_code'],
                    'event_name' => $row['event_name'],
                    'event_type' => $row['event_type'],
                    'description' => $row['description'],
                    'start_time' => $row['start_time'],
                    'end_time' => $row['end_time'],
                    'finished_at' => $row['finished_at'],
                    'duration' => $this->getEventDuration($row['start_time'], $row['end_time'])
                ];
            }
            
            return [
                'success' => true,
                'data' => [
                    'total' => count($events),
                    'events' => $events
                ]
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Lỗi khi lấy danh sách event: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Lấy danh sách server
     */
    public function getServerList() {
        try {
            $servers = Database::getAllActiveServers();
            
            $serverList = [];
            foreach ($servers as $server) {
                $serverList[] = [
                    'server_id' => $server['server_id'],
                    'server_name' => $server['server_name'],
                    'db_name' => $server['db_name'],
                    'db_host' => $server['db_host'],
                    'db_port' => $server['db_port'],
                    'created_at' => $server['created_at']
                ];
            }
            
            return [
                'success' => true,
                'data' => [
                    'servers' => $serverList,
                    'default_server_id' => Config::DEFAULT_SERVER_ID
                ]
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Lỗi khi lấy danh sách server: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Tính thời gian còn lại hoặc thời gian đến khi bắt đầu
     */
    private function getTimeRemaining($startTime, $endTime) {
    // Set timezone mặc định (thay 'Asia/Ho_Chi_Minh' bằng timezone của bạn)
    date_default_timezone_set('Asia/Ho_Chi_Minh');
    
    $now = new DateTime();
    $start = new DateTime($startTime);
    $end = new DateTime($endTime);
    
    // Debug: log thời gian để kiểm tra
    error_log("Now: " . $now->format('Y-m-d H:i:s'));
    error_log("End: " . $end->format('Y-m-d H:i:s'));
    
    // Nếu event chưa bắt đầu
    if ($now < $start) {
        $diff = $now->diff($start);
        $parts = [];
        if ($diff->d > 0) $parts[] = $diff->d . ' ngày';
        if ($diff->h > 0) $parts[] = $diff->h . ' giờ';
        if ($diff->i > 0) $parts[] = $diff->i . ' phút';
        
        return 'Bắt đầu sau ' . (count($parts) > 0 ? implode(' ', $parts) : '0 phút');
    }
    
    // Nếu event đã kết thúc
    if ($now > $end) {
        return 'Đã kết thúc';
    }
    
    // Event đang diễn ra
    $diff = $now->diff($end);
    
    $parts = [];
    if ($diff->d > 0) $parts[] = $diff->d . ' ngày';
    if ($diff->h > 0) $parts[] = $diff->h . ' giờ';
    if ($diff->i > 0) $parts[] = $diff->i . ' phút';
    
    return 'Còn lại ' . (count($parts) > 0 ? implode(' ', $parts) : '0 phút');
}
    
    /**
     * Kiểm tra event có đang diễn ra không
     */
    private function isEventOngoing($startTime, $endTime) {
        $now = new DateTime();
        $start = new DateTime($startTime);
        $end = new DateTime($endTime);
        
        return ($now >= $start && $now <= $end);
    }
    
    /**
     * Tính thời lượng event
     */
    private function getEventDuration($startTime, $endTime) {
        $start = new DateTime($startTime);
        $end = new DateTime($endTime);
        $diff = $start->diff($end);
        
        return $diff->days . ' ngày';
    }
    
    /**
     * Lấy màu theo thứ hạng
     */
    private function getRankColor($rank) {
        if ($rank == 1) return 'danger';
        if ($rank == 2) return 'warning';
        if ($rank == 3) return 'info';
        return 'dark';
    }
}