<?php
// services/WebhookService.php
require_once __DIR__ . '/ConfigService.php';

class WebhookService {
    private $accountDb;
    private $gameDbs = [];
    private $config;
    private $remoteDb;
    
    public function __construct() {
        $this->accountDb = Database::getInstance()->getConnection();
        $this->config = ConfigService::getInstance();
        $this->remoteDb = Database::getRemoteInstance()->getConnection();
    }
    
    /**
     * LẤY USER_ID TỪ PLAYER_NAME VIA tob_char
     */
    private function getUserIdFromPlayerName($playerName, $serverId = 1) {
        try {
            $gameDb = $this->getGameDb($serverId);
            
            $stmt = $gameDb->prepare("
                SELECT userId, charname 
                FROM tob_char 
                WHERE charname = ? 
                AND del = 1
                LIMIT 1
            ");
            $stmt->execute([$playerName]);
            $char = $stmt->fetch();
            
            if ($char) {
                return [
                    'success' => true,
                    'user_id' => (int)$char['userId'],
                    'player_name' => $char['charname']
                ];
            }
            
            return [
                'success' => false,
                'message' => 'Nhân vật không tồn tại'
            ];
            
        } catch (Exception $e) {
            error_log("Error getting userId from playerName: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Lỗi khi tra cứu nhân vật: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Xử lý webhook từ SePay (tự động phân loại)
     */
    public function processSepayWebhook($data) {
    try {
        $this->logWebhook($data);
        
        if (empty($data['content']) || empty($data['transferAmount']) || $data['transferType'] !== 'in') {
            error_log("❌ Invalid transaction data");
            return [
                'success' => false,
                'message' => 'Invalid transaction data'
            ];
        }
        
        $content = trim($data['content']);
        $amount = $data['transferAmount'];
        
        error_log("=== WEBHOOK RECEIVED ===");
        error_log("Raw content: " . $content);
        error_log("Amount: " . $amount);
        
        // EXTRACT phần quan trọng từ content dài
        $extractedContent = $this->extractTransactionContent($content);
        
        if (!$extractedContent) {
            error_log("❌ Cannot extract content");
            return [
                'success' => true,
                'message' => 'Transaction received but not recognized',
                'data' => [
                    'type' => 'other',
                    'content' => $content,
                    'amount' => $amount
                ]
            ];
        }
        
        error_log("Extracted content: " . $extractedContent);
        
        // CHUẨN HÓA: thay khoảng trắng bằng dấu gạch dưới
        $normalizedContent = preg_replace('/\s+/', '_', $extractedContent);
        error_log("Normalized content: " . $normalizedContent);
        
        // ✅ ƯU TIÊN 1: KIỂM TRA GÓI NẠP TRƯỚC (vì package_code có thể trùng với prefix)
        $packageResult = $this->detectPackageCode($extractedContent, $amount);
        if ($packageResult['found']) {
            error_log("✅ Detected PACKAGE ORDER");
            return $this->processPackagePurchase(
                $packageResult['package_code'],
                $packageResult['player_name'],
                $amount,
                $data['id'] ?? 'SEPAY_PKG_' . time(),
                $data['gateway'] ?? 'Unknown',
                $data['transactionDate'] ?? date('Y-m-d H:i:s')
            );
        }
        
        // ✅ ƯU TIÊN 2: Kiểm tra activation
        $activationPrefix = $this->config->get('activation_description_prefix', 'kh');
        if (strpos($normalizedContent, $activationPrefix) === 0) {
            error_log("✅ Detected ACTIVATION");
            return $this->processActivationPayment(
                $normalizedContent, 
                $amount, 
                $data['transactionDate'] ?? date('Y-m-d H:i:s'), 
                $data['accountNumber'] ?? '', 
                $data['id'] ?? 'SEPAY_' . time(), 
                $data
            );
        }
        
        // ✅ ƯU TIÊN 3: Kiểm tra nạp lượng
        $luongPrefix = $this->config->get('recharge_luong_prefix', 'nl');
        if (strpos($normalizedContent, $luongPrefix) === 0) {
            error_log("✅ Detected LUONG RECHARGE");
            $data['content'] = $normalizedContent;
            return $this->processRechargeLuong($data);
        }
        
        // ✅ ƯU TIÊN 4: Kiểm tra nạp xu
        $xuPrefix = $this->config->get('recharge_xu_prefix', 'nx');
        if (strpos($normalizedContent, $xuPrefix) === 0) {
            error_log("✅ Detected XU RECHARGE");
            $data['content'] = $normalizedContent;
            return $this->processRechargeXu($data);
        }
        
        error_log("❌ No matching transaction type found");
        return [
            'success' => true,
            'message' => 'Transaction received but not recognized',
            'data' => [
                'type' => 'other',
                'extracted_content' => $extractedContent,
                'normalized_content' => $normalizedContent,
                'amount' => $amount
            ]
        ];
        
    } catch (Exception $e) {
        error_log("❌ Webhook error: " . $e->getMessage());
        error_log("Trace: " . $e->getTraceAsString());
        return [
            'success' => false,
            'message' => 'Error processing webhook: ' . $e->getMessage()
        ];
    }
}

    /**
     * Extract transaction content từ content dài
     */
  private function extractTransactionContent($content) {
    $cleanContent = preg_replace('/\.$/', '', trim($content));
    
    error_log("=== EXTRACT CONTENT DEBUG ===");
    error_log("Original: " . $content);
    error_log("Clean: " . $cleanContent);
    
    // ✅ XỬ LÝ FORMAT SEPAY: "MBVCB.12345.67890.CONTENT_THAT_MATTERS.CT tu..."
    if (preg_match('/MBVCB\.\d+\.\d+\.([^.]+)\.CT/i', $cleanContent, $matches)) {
        $extracted = trim($matches[1]);
        error_log("✅ Extracted from MBVCB pattern: " . $extracted);
        return $extracted;
    }
    
    // ✅ XỬ LÝ FORMAT KHÁC: Tìm phần giữa các số/mã và ".CT"
    if (preg_match('/\.(\d+)\.([^.]+)\.CT/i', $cleanContent, $matches)) {
        $extracted = trim($matches[2]);
        error_log("✅ Extracted from pattern: " . $extracted);
        return $extracted;
    }
    
    $activationPrefix = $this->config->get('activation_description_prefix', 'kh');
    $luongPrefix = $this->config->get('recharge_luong_prefix', 'nl');
    $xuPrefix = $this->config->get('recharge_xu_prefix', 'nx');
    
    error_log("Prefixes - activation: {$activationPrefix}, luong: {$luongPrefix}, xu: {$xuPrefix}");
    
    // ✅ TÌM PATTERN ĐƠN GIẢN: "prefix player_name server_id"
    // Ví dụ: "nx AtaKhan 1" hoặc "QR - nx AtaKhan 1"
    
    // Thử tìm pattern: (prefix)(space hoặc underscore)(tên)(space hoặc underscore)(số)
    $allPrefixes = [$xuPrefix, $luongPrefix, $activationPrefix];
    
    foreach ($allPrefixes as $prefix) {
        error_log("Testing prefix: '{$prefix}'");
        
        // Pattern 1: Tìm "prefix player_name server_id" ở BẤT KỲ ĐÂU trong content
        // Ví dụ: "QR - nx AtaKhan 1" → extract "nx AtaKhan 1"
        if (preg_match('/(' . preg_quote($prefix, '/') . '\s+\S+\s+\d+)/i', $cleanContent, $matches)) {
            $extracted = trim($matches[1]);
            error_log("✅ MATCHED Pattern 1 for prefix '{$prefix}': " . $extracted);
            return $extracted;
        }
        
        // Pattern 2: Tìm "prefix_player_name_server_id"
        if (preg_match('/(' . preg_quote($prefix, '/') . '_\S+_\d+)/i', $cleanContent, $matches)) {
            $extracted = trim($matches[1]);
            error_log("✅ MATCHED Pattern 2 for prefix '{$prefix}': " . $extracted);
            return $extracted;
        }
        
        error_log("❌ No match for prefix '{$prefix}'");
    }
    
    // ✅ KIỂM TRA PACKAGE CODE
    try {
        $stmt = $this->accountDb->prepare("
            SELECT package_code 
            FROM recharge_packages 
            WHERE is_active = 1
        ");
        $stmt->execute();
        $packages = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        error_log("Checking " . count($packages) . " package codes");
        
        foreach ($packages as $packageCode) {
            error_log("Testing package code: '{$packageCode}'");
            
            // Pattern: "package_code player_name" 
            if (preg_match('/(' . preg_quote($packageCode, '/') . '\s+\S+)/i', $cleanContent, $matches)) {
                $extracted = trim($matches[1]);
                error_log("✅ MATCHED package code '{$packageCode}': " . $extracted);
                return $extracted;
            }
            
            if (preg_match('/(' . preg_quote($packageCode, '/') . '_\S+)/i', $cleanContent, $matches)) {
                $extracted = trim($matches[1]);
                error_log("✅ MATCHED package code '{$packageCode}': " . $extracted);
                return $extracted;
            }
        }
    } catch (Exception $e) {
        error_log("Error checking package codes: " . $e->getMessage());
    }
    
    // Nếu không match gì, trả về content gốc
    error_log("⚠️⚠️⚠️ NO PATTERN MATCHED - returning clean content");
    return $cleanContent;
}


    /**
     * Phát hiện package code từ content
     * Format: package_code player_name (VD: "GOI1 TenNhanVat" hoặc "GOI1_TenNhanVat")
     */
    private function detectPackageCode($content, $amount) {
    try {
        error_log("=== DETECTING PACKAGE CODE ===");
        error_log("Content: " . $content);
        error_log("Amount: " . $amount);
        
        // Lấy tất cả package codes từ DB
        $stmt = $this->accountDb->prepare("
            SELECT package_code, price 
            FROM recharge_packages 
            WHERE is_active = 1
        ");
        $stmt->execute();
        $packages = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        error_log("Active packages: " . count($packages));
        
        // Normalize content: thay thế khoảng trắng và underscore thành space
        $normalizedContent = preg_replace('/[_\s]+/', ' ', $content);
        error_log("Normalized for matching: " . $normalizedContent);
        
        foreach ($packages as $package) {
            $packageCode = $package['package_code'];
            $price = $package['price'];
            
            error_log("Checking package: {$packageCode} (Price: {$price})");
            
            // Kiểm tra content bắt đầu bằng package_code (case insensitive)
            if (stripos($normalizedContent, $packageCode) === 0) {
                error_log("✅ Package code matched at start: {$packageCode}");
                
                // Kiểm tra amount khớp
                if (floatval($amount) == floatval($price)) {
                    error_log("✅ Amount matched: {$amount} == {$price}");
                    
                    // Extract player name (phần sau package_code)
                    $playerName = trim(substr($normalizedContent, strlen($packageCode)));
                    $playerName = preg_replace('/\s+/', ' ', $playerName); // Normalize spaces
                    
                    error_log("Extracted player name: '{$playerName}'");
                    
                    if (!empty($playerName)) {
                        error_log("✅✅✅ PACKAGE DETECTED: Code={$packageCode}, Player={$playerName}, Amount={$amount}");
                        return [
                            'found' => true,
                            'package_code' => $packageCode,
                            'player_name' => $playerName
                        ];
                    } else {
                        error_log("❌ Player name is empty after extraction");
                    }
                } else {
                    error_log("❌ Amount mismatch: {$amount} != {$price}");
                }
            } else {
                // Thử tìm package code ở giữa content
                $pos = stripos($normalizedContent, $packageCode);
                if ($pos !== false) {
                    error_log("⚠️ Package code found at position {$pos} (not at start)");
                }
            }
        }
        
        error_log("❌ No package matched");
        return ['found' => false];
        
    } catch (Exception $e) {
        error_log("❌ Error detecting package code: " . $e->getMessage());
        return ['found' => false];
    }
}

    /**
     * Xử lý thanh toán gói (được gọi từ webhook)
     */
   private function processPackagePurchase($packageCode, $playerName, $amount, $transactionId, $bankName, $paymentTime) {
    try {
        error_log("=== PROCESSING PACKAGE PURCHASE ===");
        error_log("Package Code: {$packageCode}");
        error_log("Player Name: {$playerName}");
        error_log("Amount: {$amount}");
        error_log("Transaction ID: {$transactionId}");
        
        // 1. Kiểm tra duplicate transaction
        if ($this->isDuplicatePackageTransaction($transactionId)) {
            error_log("❌ Duplicate transaction: {$transactionId}");
            return [
                'success' => false,
                'message' => 'Transaction already processed'
            ];
        }
        
        // 2. Lấy thông tin package từ DB
        $packageStmt = $this->accountDb->prepare("
            SELECT * FROM recharge_packages 
            WHERE package_code = ? 
            AND is_active = 1
            LIMIT 1
        ");
        $packageStmt->execute([$packageCode]);
        $package = $packageStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$package) {
            error_log("❌ Package not found: {$packageCode}");
            return [
                'success' => false,
                'message' => 'Package not found: ' . $packageCode
            ];
        }
        
        error_log("✅ Package found: " . $package['package_name']);
        
        // 3. Kiểm tra amount khớp
        if ($amount != $package['price']) {
            error_log("❌ Amount mismatch. Expected: {$package['price']}, Got: {$amount}");
            return [
                'success' => false,
                'message' => 'Invalid amount for package'
            ];
        }
        
        error_log("✅ Amount matched");
        
        // 4. Tìm pending order
        $orderStmt = $this->accountDb->prepare("
            SELECT * FROM package_orders 
            WHERE player_name = ? 
            AND package_code = ?
            AND status = 'pending'
            ORDER BY created_at DESC 
            LIMIT 1
        ");
        $orderStmt->execute([$playerName, $packageCode]);
        $order = $orderStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$order) {
            error_log("❌ No pending order found for player: {$playerName}, package: {$packageCode}");
            return [
                'success' => false,
                'message' => 'No pending order found. Player must create order first.'
            ];
        }
        
        $orderId = $order['order_id'];
        $serverId = $order['server_id'];
        $userId = $order['user_id'];
        
        error_log("✅ Found order: {$orderId}, ServerId: {$serverId}, UserId: {$userId}");
        
        // 5. Cập nhật order status = paid
        $updateStmt = $this->accountDb->prepare("
            UPDATE package_orders 
            SET status = 'paid',
                transaction_id = ?,
                bank_name = ?,
                payment_time = ?,
                updated_at = NOW()
            WHERE order_id = ?
        ");
        $updateStmt->execute([$transactionId, $bankName, $paymentTime, $orderId]);
        
        error_log("✅ Order updated to 'paid'");
        
        // 6. Thêm phần thưởng vào game
        $gameDb = $this->getGameDb($serverId);
        
        $rewardStmt = $gameDb->prepare("
            INSERT INTO board_package_rewards 
            (username, xu, luong, luongKhoa, item, package_name, package_code, status, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, 0, NOW())
        ");
        
        $rewardStmt->execute([
            $playerName,
            $package['reward_xu'],
            $package['reward_luong'],
            $package['reward_luong_khoa'],
            $package['items'],
            $package['package_name'],
            $packageCode
        ]);
        
        error_log("✅ Rewards added to board_package_rewards");
        
        // 7. Cập nhật order status = completed
        $completeStmt = $this->accountDb->prepare("
            UPDATE package_orders 
            SET status = 'completed',
                updated_at = NOW()
            WHERE order_id = ?
        ");
        $completeStmt->execute([$orderId]);
        
        error_log("✅ Order status updated to 'completed'");
        
        // 8. Lưu vào lịch sử
        $historyStmt = $this->accountDb->prepare("
            INSERT INTO package_purchase_history 
            (order_id, user_id, player_name, server_id, package_code, package_name, 
             price, rewards, transaction_id) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $rewards = json_encode([
            'xu' => $package['reward_xu'],
            'luong' => $package['reward_luong'],
            'luong_khoa' => $package['reward_luong_khoa'],
            'items' => $package['items']
        ]);
        
        $historyStmt->execute([
            $orderId,
            $userId,
            $playerName,
            $serverId,
            $packageCode,
            $package['package_name'],
            $amount,
            $rewards,
            $transactionId
        ]);
        
        error_log("✅ Purchase history saved");
        error_log("✅✅✅ PACKAGE PURCHASE COMPLETED SUCCESSFULLY");
        
        return [
            'success' => true,
            'message' => 'Package purchased successfully',
            'data' => [
                'order_id' => $orderId,
                'package_code' => $packageCode,
                'package_name' => $package['package_name'],
                'player_name' => $playerName,
                'user_id' => $userId,
                'server_id' => $serverId,
                'amount' => $amount,
                'rewards' => json_decode($rewards, true),
                'transaction_id' => $transactionId,
                'completed_at' => date('Y-m-d H:i:s')
            ]
        ];
        
    } catch (Exception $e) {
        error_log("❌❌❌ Error in processPackagePurchase: " . $e->getMessage());
        error_log("Trace: " . $e->getTraceAsString());
        
        return [
            'success' => false,
            'message' => 'Error processing package purchase: ' . $e->getMessage()
        ];
    }
}

    /**
     * Kiểm tra duplicate package transaction
     */
    private function isDuplicatePackageTransaction($transactionId) {
        try {
            $stmt = $this->accountDb->prepare("
                SELECT id FROM package_orders 
                WHERE transaction_id = ? 
                AND status IN ('paid', 'completed')
                LIMIT 1
            ");
            $stmt->execute([$transactionId]);
            return $stmt->fetch() !== false;
            
        } catch (Exception $e) {
            error_log("Error checking duplicate package transaction: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Tìm order_id từ recharge_orders
     */
    private function findPendingOrder($playerName, $serverId, $amount, $type) {
        try {
            $stmt = $this->accountDb->prepare("
                SELECT order_id 
                FROM recharge_orders 
                WHERE player_name = ? 
                AND server_id = ?
                AND type = ?
                AND amount = ?
                AND status = 'pending'
                AND created_at >= DATE_SUB(NOW(), INTERVAL 30 MINUTE)
                ORDER BY created_at DESC 
                LIMIT 1
            ");
            $stmt->execute([$playerName, $serverId, $type, $amount]);
            $result = $stmt->fetch();
            
            return $result ? $result['order_id'] : null;
            
        } catch (Exception $e) {
            error_log("Error finding pending order: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Xử lý nạp xu
     */
    public function processRechargeXu($data) {
        try {
            $this->logWebhook($data, 'recharge_xu');
            
            if (empty($data['content']) || empty($data['transferAmount'])) {
                return [
                    'success' => false,
                    'message' => 'Invalid transaction data'
                ];
            }
            
            $content = $data['content'];
            $amount = $data['transferAmount'];
            $transactionDate = $data['transactionDate'] ?? date('Y-m-d H:i:s');
            $transactionId = $data['id'] ?? 'SEPAY_XU_' . time();
            $content = preg_replace('/\s+/', '_', $content);
            
            $parts = explode('_', $content);
            
            if (count($parts) < 3) {
                return [
                    'success' => false,
                    'message' => 'Invalid content format. Expected: nx_playerName_serverId'
                ];
            }
            
            $playerName = $parts[1];
            $serverId = (int)$parts[2];
            
            $userInfo = $this->getUserIdFromPlayerName($playerName, $serverId);
            
            if (!$userInfo['success']) {
                return [
                    'success' => false,
                    'message' => 'Nhân vật không tồn tại trong game. Player: ' . $playerName
                ];
            }
            
            $userId = $userInfo['user_id'];
            
            if ($this->isDuplicateTransaction($transactionId, 'recharge_xu')) {
                return [
                    'success' => false,
                    'message' => 'Transaction already processed'
                ];
            }

            $xuAmount = $this->calculateXuAmount($amount);

            $isFirstRecharge = $this->isFirstRecharge($userId);
            if ($isFirstRecharge) {
                $firstRechargeMultiplier = $this->config->get('nap_lan_dau', 1);
                $xuAmount = floor($xuAmount * $firstRechargeMultiplier);
                error_log("First recharge for userId {$userId} - Xu x{$firstRechargeMultiplier}: {$xuAmount}");
            }
            
            if ($xuAmount === 0) {
                return [
                    'success' => false,
                    'message' => 'Invalid recharge amount. Amount: ' . $amount
                ];
            }
            
            $orderId = $this->findPendingOrder($playerName, $serverId, $amount, 'recharge_xu');
            
            if (!$orderId) {
                $orderId = 'XU_' . date('YmdHis') . '_' . $playerName;
                
                $this->createRechargeOrderIfNotExists(
                    $orderId, 
                    $userId,
                    $playerName, 
                    $serverId, 
                    'recharge_xu', 
                    $amount, 
                    $xuAmount
                );
            }
            
            $this->updateRechargeOrder(
                $orderId,
                $transactionId,
                $data['gateway'] ?? 'Unknown',
                $transactionDate,
                'paid'
            );
            
            $this->saveRechargeTransaction(
                $orderId, 
                $userId,
                $playerName, 
                $serverId, 
                $amount, 
                $xuAmount, 
                'recharge_xu', 
                $transactionId, 
                $data, 
                $transactionDate
            );
            
            $result = $this->addXuToGame($playerName, $serverId, $xuAmount);
            
            if (!$result['success']) {
                $this->updateTransactionStatus($orderId, 'failed');
                $this->updateRechargeOrderStatus($orderId, 'failed');
                return [
                    'success' => false,
                    'message' => 'Failed to add xu: ' . $result['message']
                ];
            }
            
            $this->updateTransactionStatus($orderId, 'completed');
            $this->updateRechargeOrderStatus($orderId, 'completed');
            
            $this->updateTopNap($userId, $playerName, $serverId, $amount, $xuAmount, 0, 0, 1);
            $this->updateEventRecharge($userId, $playerName, $serverId, $amount, $xuAmount, 0, 0);
            $this->logRecharge($userId, $serverId, $orderId, $amount, $xuAmount, 0, 'completed');
            
            return [
                'success' => true,
                'message' => 'Xu recharged successfully',
                'data' => [
                    'order_id' => $orderId,
                    'user_id' => $userId,
                    'player_name' => $playerName,
                    'server_id' => $serverId,
                    'amount_paid' => $amount,
                    'xu_received' => $xuAmount,
                    'is_first_recharge' => $isFirstRecharge,
                    'first_recharge_bonus' => $isFirstRecharge ? $this->config->get('nap_lan_dau', 1) : 1,
                    'transaction_id' => $transactionId,
                    'completed_at' => date('Y-m-d H:i:s')
                ]
            ];
            
        } catch (Exception $e) {
            error_log("Error in processRechargeXu: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Error processing xu recharge: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Xử lý nạp lượng
     */
    public function processRechargeLuong($data) {
        try {
            $this->logWebhook($data, 'recharge_luong');
            
            if (empty($data['content']) || empty($data['transferAmount'])) {
                return [
                    'success' => false,
                    'message' => 'Invalid transaction data'
                ];
            }
            
            $content = $data['content'];
            $amount = $data['transferAmount'];
            $transactionDate = $data['transactionDate'] ?? date('Y-m-d H:i:s');
            $transactionId = $data['id'] ?? 'SEPAY_LUONG_' . time();
            
            $content = preg_replace('/\s+/', '_', $content);
            $parts = explode('_', $content);
            
            if (count($parts) < 3) {
                return [
                    'success' => false,
                    'message' => 'Invalid content format. Expected: nl_playerName_serverId'
                ];
            }
            
            $playerName = $parts[1];
            $serverId = (int)$parts[2];
            
            $userInfo = $this->getUserIdFromPlayerName($playerName, $serverId);
            
            if (!$userInfo['success']) {
                return [
                    'success' => false,
                    'message' => 'Nhân vật không tồn tại trong game. Player: ' . $playerName
                ];
            }
            
            $userId = $userInfo['user_id'];
            
            if ($this->isDuplicateTransaction($transactionId, 'recharge_luong')) {
                return [
                    'success' => false,
                    'message' => 'Transaction already processed'
                ];
            }
            
            $baseLuongAmount = floor($amount / $this->config->get('luong_exchange_rate'));
            $baseLuongKhoaAmount = floor($baseLuongAmount * $this->config->get('luong_khoa_percent'));

            $bonusMultiplier = $this->config->get('luong_bonus_multiplier');
            $luongAmount = floor($baseLuongAmount * $bonusMultiplier);
            $luongKhoaAmount = floor($baseLuongKhoaAmount * $bonusMultiplier);

            $isFirstRecharge = $this->isFirstRecharge($userId);
            if ($isFirstRecharge) {
                $firstRechargeMultiplier = $this->config->get('nap_lan_dau', 1);
                $luongAmount = floor($luongAmount * $firstRechargeMultiplier);
                $luongKhoaAmount = floor($luongKhoaAmount * $firstRechargeMultiplier);
                error_log("First recharge for userId {$userId} - Luong x{$firstRechargeMultiplier}: {$luongAmount}");
            }
            
            if ($baseLuongAmount === 0) {
                return [
                    'success' => false,
                    'message' => 'Invalid recharge amount'
                ];
            }
            
            $orderId = $this->findPendingOrder($playerName, $serverId, $amount, 'recharge_luong');
            
            if (!$orderId) {
                $orderId = 'LUONG_' . date('YmdHis') . '_' . $playerName;
                
                $this->createRechargeOrderIfNotExists(
                    $orderId, 
                    $userId,
                    $playerName, 
                    $serverId, 
                    'recharge_luong', 
                    $amount, 
                    $luongAmount,
                    $luongKhoaAmount
                );
            }
            
            $this->updateRechargeOrder(
                $orderId,
                $transactionId,
                $data['gateway'] ?? 'Unknown',
                $transactionDate,
                'paid'
            );
            
            $this->saveRechargeTransaction(
                $orderId, 
                $userId,
                $playerName, 
                $serverId, 
                $amount, 
                $luongAmount, 
                'recharge_luong', 
                $transactionId, 
                $data, 
                $transactionDate, 
                $luongKhoaAmount
            );
            
            $result = $this->addLuongToGame($playerName, $serverId, $luongAmount, $luongKhoaAmount);
            
            if (!$result['success']) {
                $this->updateTransactionStatus($orderId, 'failed');
                $this->updateRechargeOrderStatus($orderId, 'failed');
                return [
                    'success' => false,
                    'message' => 'Failed to add luong: ' . $result['message']
                ];
            }
            
            $this->updateTransactionStatus($orderId, 'completed');
            $this->updateRechargeOrderStatus($orderId, 'completed');
            
            $this->updateTopNap($userId, $playerName, $serverId, $amount, 0, $luongAmount, $luongKhoaAmount, 1);
            $this->updateEventRecharge($userId, $playerName, $serverId, $amount, 0, $luongAmount, $luongKhoaAmount);
            $this->logRecharge($userId, $serverId, $orderId, $amount, 0, $luongAmount, 'completed', $luongKhoaAmount);
            
            return [
                'success' => true,
                'message' => 'Luong recharged successfully',
                'data' => [
                    'order_id' => $orderId,
                    'user_id' => $userId,
                    'player_name' => $playerName,
                    'server_id' => $serverId,
                    'amount_paid' => $amount,
                    'luong_received' => $luongAmount,
                    'luong_khoa_received' => $luongKhoaAmount,
                    'is_first_recharge' => $isFirstRecharge,
                    'first_recharge_bonus' => $isFirstRecharge ? $this->config->get('nap_lan_dau', 1) : 1,
                    'transaction_id' => $transactionId,
                    'bonus_multiplier' => $bonusMultiplier,
                    'completed_at' => date('Y-m-d H:i:s')
                ]
            ];
            
        } catch (Exception $e) {
            error_log("Error in processRechargeLuong: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Error processing luong recharge: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Xử lý thanh toán kích hoạt
     */
    private function processActivationPayment($content, $amount, $transactionDate, $accountNumber, $transactionId, $webhookData) {
        try {
            error_log("=== ACTIVATION PAYMENT ===");
            
            $parts = explode('_', $content);
            
            if (count($parts) < 3) {
                return [
                    'success' => false,
                    'message' => 'Invalid content format. Expected: kh_username_serverId'
                ];
            }
            
            $username = trim($parts[1]);
            $serverId = (int)$parts[2];
            
            $expectedAmount = $this->config->get('activation_amount');
            if ($amount != $expectedAmount) {
                return [
                    'success' => false,
                    'message' => 'Invalid amount'
                ];
            }
            
            $checkStmt = $this->accountDb->prepare("
                SELECT * FROM activation_requests 
                WHERE transaction_id = ? 
                AND status IN ('paid', 'completed')
                LIMIT 1
            ");
            $checkStmt->execute([$transactionId]);
            
            if ($checkStmt->fetch()) {
                return [
                    'success' => false,
                    'message' => 'Transaction already processed'
                ];
            }
            
            $userStmt = $this->remoteDb->prepare("
                SELECT id, username 
                FROM team_user 
                WHERE username = ? 
                LIMIT 1
            ");
            $userStmt->execute([$username]);
            $user = $userStmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user) {
                return [
                    'success' => false,
                    'message' => 'User not found: ' . $username
                ];
            }
            
            $userId = $user['id'];
            
            $orderStmt = $this->accountDb->prepare("
                SELECT * FROM activation_requests 
                WHERE username = ? 
                AND server_id = ?
                AND status = 'pending'
                AND amount = ?
                ORDER BY created_at DESC 
                LIMIT 1
            ");
            $orderStmt->execute([$username, $serverId, $expectedAmount]);
            $order = $orderStmt->fetch(PDO::FETCH_ASSOC);
            
            $orderId = $order ? $order['order_id'] : 'AUTO_' . date('YmdHis') . '_' . $userId;
            
            if (!$order) {
                $insertStmt = $this->accountDb->prepare("
                    INSERT INTO activation_requests 
                    (order_id, user_id, username, server_id, amount, status, transaction_id, bank_name, payment_time) 
                    VALUES (?, ?, ?, ?, ?, 'paid', ?, ?, ?)
                ");
                
                $insertStmt->execute([
                    $orderId,
                    $userId,
                    $username,
                    $serverId,
                    $expectedAmount,
                    $transactionId,
                    $webhookData['gateway'] ?? 'Unknown',
                    $transactionDate
                ]);
            } else {
                $updateStmt = $this->accountDb->prepare("
                    UPDATE activation_requests 
                    SET status = 'paid',
                        transaction_id = ?,
                        bank_name = ?,
                        payment_time = ?,
                        updated_at = NOW()
                    WHERE order_id = ? AND status = 'pending'
                ");
                
                $updateStmt->execute([
                    $transactionId,
                    $webhookData['gateway'] ?? 'Unknown',
                    $transactionDate,
                    $order['order_id']
                ]);
                
                $orderId = $order['order_id'];
            }
            
            $activationResult = $this->activateAccount($userId, $username, $serverId, $orderId);
            
            if (!$activationResult['success']) {
                $this->accountDb->prepare("
                    UPDATE activation_requests 
                    SET status = 'failed',
                        updated_at = NOW()
                    WHERE order_id = ?
                ")->execute([$orderId]);
                
                return [
                    'success' => false,
                    'message' => 'Activation failed: ' . $activationResult['message']
                ];
            }
            
            $this->accountDb->prepare("
                UPDATE activation_requests 
                SET status = 'completed',
                    updated_at = NOW()
                WHERE order_id = ?
            ")->execute([$orderId]);
            
            $rewards = $activationResult['rewards'] ?? [];
            $rewardXu = $rewards['xu'] ?? $this->config->get('activation_reward_xu');
            $rewardLuong = $rewards['luong'] ?? $this->config->get('activation_reward_luong');
            $rewardLuongKhoa = $rewards['luongK'] ?? $this->config->get('activation_reward_luong_khoa', 0);
            
            $this->updateTopNap($userId, $username, $serverId, $amount, $rewardXu, $rewardLuong, $rewardLuongKhoa, 1);
            $this->updateEventRecharge($userId, $username, $serverId, $amount, $rewardXu, $rewardLuong, $rewardLuongKhoa);
            $this->logActivation($userId, $serverId, $orderId, $amount, 'completed');
            
            return [
                'success' => true,
                'message' => 'Account activated successfully',
                'data' => [
                    'order_id' => $orderId,
                    'user_id' => $userId,
                    'username' => $username,
                    'server_id' => $serverId,
                    'amount' => $amount,
                    'status' => 'completed',
                    'rewards' => $activationResult['rewards'],
                    'transaction_id' => $transactionId,
                    'activated_at' => date('Y-m-d H:i:s')
                ]
            ];
            
        } catch (Exception $e) {
            error_log("Error in processActivationPayment: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Error processing activation: ' . $e->getMessage()
            ];
        }
    }

    // ... (các helper methods tiếp theo trong part 2)
// WebhookService - Part 2: Helper Methods

    /**
     * Tạo recharge order nếu chưa tồn tại
     */
    private function createRechargeOrderIfNotExists($orderId, $userId, $playerName, $serverId, $type, $amount, $expectedReward, $expectedLuongKhoa = 0) {
        try {
            $checkStmt = $this->accountDb->prepare("
                SELECT id FROM recharge_orders WHERE order_id = ? LIMIT 1
            ");
            $checkStmt->execute([$orderId]);
            
            if (!$checkStmt->fetch()) {
                $prefix = $type === 'recharge_xu' ? $this->config->get('recharge_xu_prefix') : $this->config->get('recharge_luong_prefix');
                $description = "{$prefix} {$playerName} {$serverId}";
                
                $qrUrl = "https://qr.sepay.vn/img?" . http_build_query([
                    'acc' => $this->config->get('vietqr_account'),
                    'bank' => $this->config->get('vietqr_bank'),
                    'amount' => $amount,
                    'des' => $description,
                    'template' => 'compact'
                ]);
                
                $stmt = $this->accountDb->prepare("
                    INSERT INTO recharge_orders 
                    (order_id, user_id, player_name, server_id, type, amount, expected_reward, 
                     expected_luong_khoa, qr_code_url, status, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW())
                ");
                
                $stmt->execute([
                    $orderId,
                    $userId,
                    $playerName,
                    $serverId,
                    $type,
                    $amount,
                    $expectedReward,
                    $expectedLuongKhoa,
                    $qrUrl
                ]);
            }
        } catch (Exception $e) {
            error_log("Error creating recharge order: " . $e->getMessage());
        }
    }

    /**
     * Cập nhật recharge order
     */
    private function updateRechargeOrder($orderId, $transactionId, $bankName, $paymentTime, $status = 'paid') {
        try {
            $stmt = $this->accountDb->prepare("
                UPDATE recharge_orders 
                SET status = ?,
                    transaction_id = ?,
                    bank_name = ?,
                    payment_time = ?,
                    updated_at = NOW()
                WHERE order_id = ?
            ");
            
            $stmt->execute([
                $status,
                $transactionId,
                $bankName,
                $paymentTime,
                $orderId
            ]);
            
            return $stmt->rowCount() > 0;
        } catch (Exception $e) {
            error_log("Error updating recharge order: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Cập nhật trạng thái recharge order
     */
    private function updateRechargeOrderStatus($orderId, $status) {
        try {
            $stmt = $this->accountDb->prepare("
                UPDATE recharge_orders 
                SET status = ?,
                    updated_at = NOW()
                WHERE order_id = ?
            ");
            
            $stmt->execute([$status, $orderId]);
            
            return $stmt->rowCount() > 0;
        } catch (Exception $e) {
            error_log("Error updating recharge order status: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Cập nhật bảng topnap
     */
    private function updateTopNap($userId, $playerName, $serverId, $amount, $xuAmount, $luongAmount, $luongKhoaAmount, $rechargeCount = 1) {
        try {
            $checkStmt = $this->accountDb->prepare("
                SELECT id, total_amount, total_xu, total_luong, total_luong_khoa, total_recharge 
                FROM topnap 
                WHERE user_id = ? AND server_id = ?
                LIMIT 1
            ");
            $checkStmt->execute([$userId, $serverId]);
            $existingRecord = $checkStmt->fetch();
            
            if ($existingRecord) {
                $newTotalAmount = $existingRecord['total_amount'] + $amount;
                $newTotalXu = $existingRecord['total_xu'] + $xuAmount;
                $newTotalLuong = $existingRecord['total_luong'] + $luongAmount;
                $newTotalLuongKhoa = $existingRecord['total_luong_khoa'] + $luongKhoaAmount;
                $newTotalRecharge = $existingRecord['total_recharge'] + $rechargeCount;
                
                $updateStmt = $this->accountDb->prepare("
                    UPDATE topnap 
                    SET username = ?,
                        total_amount = ?,
                        total_xu = ?,
                        total_luong = ?,
                        total_luong_khoa = ?,
                        total_recharge = ?,
                        last_recharge_at = NOW(),
                        updated_at = NOW()
                    WHERE id = ?
                ");
                
                $updateStmt->execute([
                    $playerName,
                    $newTotalAmount,
                    $newTotalXu,
                    $newTotalLuong,
                    $newTotalLuongKhoa,
                    $newTotalRecharge,
                    $existingRecord['id']
                ]);
                
                return [
                    'success' => true,
                    'action' => 'updated',
                    'old_amount' => $existingRecord['total_amount'],
                    'new_amount' => $newTotalAmount
                ];
            } else {
                $insertStmt = $this->accountDb->prepare("
                    INSERT INTO topnap 
                    (user_id, username, server_id, total_amount, total_xu, total_luong, total_luong_khoa, total_recharge, last_recharge_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
                ");
                
                $insertStmt->execute([
                    $userId,
                    $playerName,
                    $serverId,
                    $amount,
                    $xuAmount,
                    $luongAmount,
                    $luongKhoaAmount,
                    $rechargeCount
                ]);
                
                return [
                    'success' => true,
                    'action' => 'created',
                    'new_amount' => $amount
                ];
            }
            
        } catch (Exception $e) {
            error_log("Error updating topnap: " . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Cập nhật event recharge
     */
    /**
 * Cập nhật event recharge
 */
private function updateEventRecharge($userId, $playerName, $serverId, $amount, $xuAmount, $luongAmount, $luongKhoaAmount) {
    try {
        $stmt = $this->accountDb->prepare("
            SELECT id, start_time, end_time 
            FROM events 
            WHERE event_type = 'recharge'
            AND is_active = 1 
            AND is_finished = 0
            AND NOW() BETWEEN start_time AND end_time
        ");
        $stmt->execute();
        $activeEvents = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($activeEvents as $event) {
            $eventId = $event['id'];
            
            $checkStmt = $this->accountDb->prepare("
                SELECT id, total_amount, total_xu, total_luong, total_luong_khoa, total_recharge 
                FROM event_recharge 
                WHERE event_id = ? AND user_id = ? AND server_id = ?
                LIMIT 1
            ");
            $checkStmt->execute([$eventId, $userId, $serverId]);
            $existingRecord = $checkStmt->fetch(PDO::FETCH_ASSOC);
            
            if ($existingRecord) {
                // THAY ĐỔI: Cập nhật cả username để đảm bảo luôn đúng tên nhân vật mới nhất
                $updateStmt = $this->accountDb->prepare("
                    UPDATE event_recharge 
                    SET username = ?,
                        total_amount = total_amount + ?,
                        total_xu = total_xu + ?,
                        total_luong = total_luong + ?,
                        total_luong_khoa = total_luong_khoa + ?,
                        total_recharge = total_recharge + 1,
                        last_recharge_at = NOW(),
                        updated_at = NOW()
                    WHERE id = ?
                ");
                $updateStmt->execute([
                    $playerName,  // Cập nhật tên nhân vật
                    $amount,
                    $xuAmount,
                    $luongAmount,
                    $luongKhoaAmount,
                    $existingRecord['id']
                ]);
            } else {
                // THAY ĐỔI: Lưu playerName thay vì username
                $insertStmt = $this->accountDb->prepare("
                    INSERT INTO event_recharge 
                    (event_id, user_id, username, server_id, total_amount, total_xu, total_luong, total_luong_khoa, total_recharge, first_recharge_at, last_recharge_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, NOW(), NOW())
                ");
                $insertStmt->execute([
                    $eventId,
                    $userId,
                    $playerName,  // Lưu tên nhân vật thay vì tên tài khoản
                    $serverId,
                    $amount,
                    $xuAmount,
                    $luongAmount,
                    $luongKhoaAmount
                ]);
            }
        }
        
        return ['success' => true, 'events_updated' => count($activeEvents)];
        
    } catch (Exception $e) {
        error_log("Error updating event_recharge: " . $e->getMessage());
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

    /**
     * Kích hoạt tài khoản
     */
    private function activateAccount($userId, $username, $serverId = 1, $orderId = null) {
        try {
            $gameDb = $this->getGameDb($serverId);
            
            $checkStmt = $gameDb->prepare("SELECT * FROM `5h_active` WHERE `userID` = ? LIMIT 1");
            $checkStmt->execute([$userId]);
            
            if ($checkStmt->fetch()) {
                return [
                    'success' => false,
                    'message' => 'Tài khoản đã được kích hoạt'
                ];
            }
            
            $updateActiveStmt = $this->remoteDb->prepare("
                UPDATE team_user 
                SET active = 1 
                WHERE id = ?
            ");
            $updateActiveStmt->execute([$userId]);
            
            $activeStmt = $gameDb->prepare("
                INSERT INTO `5h_active` (`userID`, `username`, `time_end`) 
                VALUES (?, ?, ?)
            ");
            $activeStmt->execute([$userId, $username, -1]);
            
            $rewardXu = $this->config->get('activation_reward_xu');
            $rewardLuong = $this->config->get('activation_reward_luong');
            $rewardLuongKhoa = $this->config->get('activation_reward_luong_khoa', $rewardLuong);
            
            $rewardStmt = $gameDb->prepare("
                INSERT INTO `board_created` 
                (`xu`, `luong`, `luongK`, `svID`, `username`, `ve`) 
                VALUES (?, ?, ?, ?, ?, '0')
            ");
            $rewardStmt->execute([
                $rewardXu,
                $rewardLuong,
                $rewardLuongKhoa,
                -1,
                $userId
            ]);
            
            return [
                'success' => true,
                'rewards' => [
                    'xu' => $rewardXu,
                    'luong' => $rewardLuong,
                    'luongK' => $rewardLuongKhoa,
                    'message' => 'Kích hoạt thành công'
                ]
            ];
            
        } catch (Exception $e) {
            error_log("Activation error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Lỗi khi kích hoạt: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Tính xu dựa trên mệnh giá
     */
    private function calculateXuAmount($amount) {
        $rates = $this->config->get('xu_exchange_rates', []);
        $xuAmount = $rates[$amount] ?? 0;
        $bonusMultiplier = $this->config->get('xu_bonus_multiplier', 1);
        return $xuAmount * $bonusMultiplier;
    }

    /**
     * Kiểm tra transaction đã xử lý chưa
     */
    private function isDuplicateTransaction($transactionId, $type) {
        $stmt = $this->accountDb->prepare("
            SELECT id FROM recharge_transactions 
            WHERE transaction_id = ? 
            AND type = ?
            AND status IN ('completed', 'processing')
            LIMIT 1
        ");
        $stmt->execute([$transactionId, $type]);
        return $stmt->fetch() !== false;
    }

    /**
     * Lưu transaction vào database
     */
    private function saveRechargeTransaction($orderId, $userId, $playerName, $serverId, $amount, $rewardAmount, $type, $transactionId, $webhookData, $transactionDate, $luongKhoa = 0) {
        $stmt = $this->accountDb->prepare("
            INSERT INTO recharge_transactions 
            (order_id, user_id, player_name, server_id, amount, reward_amount, luong_khoa, type, status, transaction_id, bank_name, payment_time, webhook_data) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'processing', ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $orderId,
            $userId,
            $playerName,
            $serverId,
            $amount,
            $rewardAmount,
            $luongKhoa,
            $type,
            $transactionId,
            $webhookData['gateway'] ?? 'Unknown',
            $transactionDate,
            json_encode($webhookData)
        ]);
    }

    /**
     * Cập nhật trạng thái transaction
     */
    private function updateTransactionStatus($orderId, $status) {
        $stmt = $this->accountDb->prepare("
            UPDATE recharge_transactions 
            SET status = ?, updated_at = NOW()
            WHERE order_id = ?
        ");
        $stmt->execute([$status, $orderId]);
    }

    /**
     * Nạp xu vào game
     */
    private function addXuToGame($playerName, $serverId, $xuAmount) {
        try {
            $gameDb = $this->getGameDb($serverId);
            
            $stmt = $gameDb->prepare("
                INSERT INTO board_naptien (xu, luong, luongKhoa, username) 
                VALUES (?, 0, 0, ?)
            ");
            
            $stmt->execute([$xuAmount, $playerName]);
            
            return ['success' => true];
        } catch (Exception $e) {
            error_log("Add xu error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Nạp lượng vào game
     */
    private function addLuongToGame($playerName, $serverId, $luongAmount, $luongKhoaAmount) {
        try {
            $gameDb = $this->getGameDb($serverId);
            
            $stmt = $gameDb->prepare("
                INSERT INTO board_naptien (xu, luong, luongKhoa, username) 
                VALUES (0, ?, ?, ?)
            ");
            
            $stmt->execute([$luongAmount, $luongKhoaAmount, $playerName]);
            
            return ['success' => true];
        } catch (Exception $e) {
            error_log("Add luong error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Log webhook nhận được
     */
    private function logWebhook($data, $type = 'sepay') {
        try {
            $stmt = $this->accountDb->prepare("
                INSERT INTO webhook_logs 
                (type, data, created_at) 
                VALUES (?, ?, NOW())
            ");
            
            $stmt->execute([$type, json_encode($data)]);
        } catch (Exception $e) {
            error_log("Failed to log webhook: " . $e->getMessage());
        }
    }

    /**
     * Log kích hoạt
     */
    private function logActivation($userId, $serverId, $orderId, $amount, $status) {
        try {
            $stmt = $this->accountDb->prepare("
                INSERT INTO activation_logs 
                (user_id, order_id, server_id, amount, status, created_at) 
                VALUES (?, ?, ?, ?, ?, NOW())
            ");
            
            $stmt->execute([$userId, $orderId, $serverId, $amount, $status]);
        } catch (Exception $e) {
            error_log("Failed to log activation: " . $e->getMessage());
        }
    }

    /**
     * Log recharge
     */
    private function logRecharge($userId, $serverId, $orderId, $amount, $xu, $luong, $status, $luongKhoa = 0) {
        try {
            $stmt = $this->accountDb->prepare("
                INSERT INTO recharge_logs 
                (user_id, order_id, server_id, amount, xu, luong, luong_khoa, status, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            
            $stmt->execute([$userId, $orderId, $serverId, $amount, $xu, $luong, $luongKhoa, $status]);
        } catch (Exception $e) {
            error_log("Failed to log recharge: " . $e->getMessage());
        }
    }

    /**
     * Lấy kết nối game database
     */
    private function getGameDb($serverId = null) {
        if ($serverId === null) {
            $serverId = Config::DEFAULT_SERVER_ID;
        }

        if (!isset($this->gameDbs[$serverId])) {
            $dbInstance = Database::getGameInstance($serverId);
            $this->gameDbs[$serverId] = $dbInstance->getConnection();
        }
        
        return $this->gameDbs[$serverId];
    }

    /**
     * Kiểm tra user đã từng nạp thành công chưa
     */
    private function isFirstRecharge($userId) {
        try {
            $stmt = $this->accountDb->prepare("
                SELECT COUNT(*) as count 
                FROM recharge_logs 
                WHERE user_id = ? 
                AND status = 'completed'
                LIMIT 1
            ");
            $stmt->execute([$userId]);
            $result = $stmt->fetch();
            
            return ($result['count'] == 0);
            
        } catch (Exception $e) {
            error_log("Error checking first recharge: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Khởi tạo bảng log
     */
    public function initLogTables() {
        try {
            $sql = "
                CREATE TABLE IF NOT EXISTS `webhook_logs` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `type` VARCHAR(50) NOT NULL,
                    `data` TEXT,
                    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_type (type),
                    INDEX idx_created_at (created_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                
                CREATE TABLE IF NOT EXISTS `activation_logs` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `user_id` INT NOT NULL,
                    `order_id` VARCHAR(50),
                    `server_id` INT DEFAULT 1,
                    `amount` DECIMAL(10,2),
                    `status` VARCHAR(50),
                    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_user_id (user_id),
                    INDEX idx_order_id (order_id),
                    INDEX idx_status (status)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                
                CREATE TABLE IF NOT EXISTS `recharge_transactions` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `order_id` VARCHAR(50) UNIQUE NOT NULL,
                    `user_id` INT NOT NULL,
                    `player_name` VARCHAR(100),
                    `server_id` INT DEFAULT 1,
                    `amount` DECIMAL(10,2) NOT NULL,
                    `reward_amount` BIGINT DEFAULT 0,
                    `luong_khoa` BIGINT DEFAULT 0,
                    `type` ENUM('recharge_xu', 'recharge_luong') NOT NULL,
                    `status` ENUM('pending', 'processing', 'completed', 'failed') DEFAULT 'pending',
                    `transaction_id` VARCHAR(100),
                    `bank_name` VARCHAR(100),
                    `payment_time` DATETIME,
                    `webhook_data` TEXT,
                    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_user_id (user_id),
                    INDEX idx_player_name (player_name),
                    INDEX idx_order_id (order_id),
                    INDEX idx_transaction_id (transaction_id),
                    INDEX idx_type (type),
                    INDEX idx_status (status)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                
                CREATE TABLE IF NOT EXISTS `recharge_logs` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `user_id` INT NOT NULL,
                    `order_id` VARCHAR(50),
                    `server_id` INT DEFAULT 1,
                    `amount` DECIMAL(10,2),
                    `xu` BIGINT DEFAULT 0,
                    `luong` BIGINT DEFAULT 0,
                    `luong_khoa` BIGINT DEFAULT 0,
                    `status` VARCHAR(50),
                    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_user_id (user_id),
                    INDEX idx_order_id (order_id),
                    INDEX idx_status (status)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ";
            
            $this->accountDb->exec($sql);
            
        } catch (Exception $e) {
            error_log("Init log tables error: " . $e->getMessage());
        }
    }
}