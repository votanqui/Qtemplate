<?php
// services/PackageService.php

require_once __DIR__ . '/ConfigService.php';

class PackageService {
    private $accountDb;
    private $gameDbs = [];
    private $config;
    private $remoteDb;
    
    public function __construct() {
        $this->accountDb = Database::getInstance()->getConnection();
        $this->config = ConfigService::getInstance();
        $this->remoteDb = Database::getRemoteInstance()->getConnection();
        $this->initTables();
    }
    
    /**
     * Khởi tạo bảng
     */
    private function initTables() {
        try {
            $sql = "
                -- Bảng định nghĩa gói nạp
                CREATE TABLE IF NOT EXISTS `recharge_packages` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `package_code` VARCHAR(50) UNIQUE NOT NULL,
                    `package_name` VARCHAR(255) NOT NULL,
                    `price` DECIMAL(12,2) NOT NULL,
                    `reward_xu` BIGINT DEFAULT 0,
                    `reward_luong` BIGINT DEFAULT 0,
                    `reward_luong_khoa` BIGINT DEFAULT 0,
                    `items` TEXT COMMENT 'Format: DB:685:1:-1,GEM:249:2000:-1',
                    `description` TEXT,
                    `image_url` VARCHAR(500),
                    `display_order` INT DEFAULT 0,
                    `is_active` TINYINT(1) DEFAULT 1,
                    `is_hot` TINYINT(1) DEFAULT 0,
                    `discount_percent` INT DEFAULT 0,
                    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_active (is_active),
                    INDEX idx_display (display_order)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                
                -- Bảng order mua gói
                CREATE TABLE IF NOT EXISTS `package_orders` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `order_id` VARCHAR(50) UNIQUE NOT NULL,
                    `user_id` INT NOT NULL,
                    `player_name` VARCHAR(100) NOT NULL,
                    `server_id` INT DEFAULT 1,
                    `package_id` INT NOT NULL,
                    `package_code` VARCHAR(50) NOT NULL,
                    `package_name` VARCHAR(255) NOT NULL,
                    `price` DECIMAL(12,2) NOT NULL,
                    `reward_xu` BIGINT DEFAULT 0,
                    `reward_luong` BIGINT DEFAULT 0,
                    `reward_luong_khoa` BIGINT DEFAULT 0,
                    `items` TEXT,
                    `status` ENUM('pending', 'paid', 'completed', 'failed', 'cancelled') DEFAULT 'pending',
                    `qr_code_url` TEXT,
                    `transaction_id` VARCHAR(100),
                    `bank_name` VARCHAR(50),
                    `payment_time` DATETIME,
                    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_user_id (user_id),
                    INDEX idx_player_name (player_name),
                    INDEX idx_order_id (order_id),
                    INDEX idx_status (status),
                    INDEX idx_package_id (package_id),
                    FOREIGN KEY (package_id) REFERENCES recharge_packages(id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
                
                -- Bảng lịch sử mua gói
                CREATE TABLE IF NOT EXISTS `package_purchase_history` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `order_id` VARCHAR(50) NOT NULL,
                    `user_id` INT NOT NULL,
                    `player_name` VARCHAR(100) NOT NULL,
                    `server_id` INT DEFAULT 1,
                    `package_code` VARCHAR(50) NOT NULL,
                    `package_name` VARCHAR(255) NOT NULL,
                    `price` DECIMAL(12,2) NOT NULL,
                    `rewards` TEXT COMMENT 'JSON format',
                    `transaction_id` VARCHAR(100),
                    `purchased_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_user_id (user_id),
                    INDEX idx_player_name (player_name),
                    INDEX idx_order_id (order_id),
                    INDEX idx_purchased_at (purchased_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ";
            
            $this->accountDb->exec($sql);
            
        } catch (Exception $e) {
            error_log("Init package tables error: " . $e->getMessage());
        }
    }
    
    /**
     * Lấy user_id từ player_name
     */
    private function getUserIdFromPlayerName($playerName, $serverId = 1) {
        try {
            $gameDb = $this->getGameDb($serverId);
            
            $stmt = $gameDb->prepare("
                SELECT userId, charname 
                FROM tob_char 
                WHERE charname = ? 
                AND del = 1
                LIMIT 1
            ");
            $stmt->execute([$playerName]);
            $char = $stmt->fetch();
            
            if ($char) {
                return [
                    'success' => true,
                    'user_id' => (int)$char['userId'],
                    'player_name' => $char['charname']
                ];
            }
            
            return [
                'success' => false,
                'message' => 'Nhân vật không tồn tại'
            ];
            
        } catch (Exception $e) {
            error_log("Error getting userId from playerName: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Lỗi khi tra cứu nhân vật: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Lấy danh sách tất cả gói nạp đang active
     */
    public function getAllPackages() {
        try {
            $stmt = $this->accountDb->prepare("
                SELECT 
                    id,
                    package_code,
                    package_name,
                    price,
                    description,
                    image_url,
                    display_order,
                    is_hot,
                    discount_percent
                FROM recharge_packages 
                WHERE is_active = 1
                ORDER BY display_order ASC, id DESC
            ");
            
            $stmt->execute();
            $packages = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $formattedPackages = [];
            foreach ($packages as $package) {
                $formattedPackages[] = [
                    'id' => (int)$package['id'],
                    'package_code' => $package['package_code'],
                    'package_name' => $package['package_name'],
                    'price' => (float)$package['price'],
                    'description' => $package['description'],
                    'image_url' => $package['image_url'],
                    'display_order' => (int)$package['display_order'],
                    'is_hot' => (bool)$package['is_hot'],
                    'discount_percent' => (int)$package['discount_percent']
                ];
            }
            
            return [
                'success' => true,
                'data' => $formattedPackages
            ];
            
        } catch (Exception $e) {
            error_log("Error getting packages: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Lỗi khi lấy danh sách gói nạp: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Lấy thông tin chi tiết 1 gói
     */
    public function getPackageById($packageId) {
        try {
            $stmt = $this->accountDb->prepare("
                SELECT * FROM recharge_packages 
                WHERE id = ? AND is_active = 1
                LIMIT 1
            ");
            $stmt->execute([$packageId]);
            $package = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$package) {
                return [
                    'success' => false,
                    'message' => 'Gói nạp không tồn tại'
                ];
            }
            
            return [
                'success' => true,
                'data' => [
                    'id' => (int)$package['id'],
                    'package_code' => $package['package_code'],
                    'package_name' => $package['package_name'],
                    'price' => (float)$package['price'],
                    'reward_xu' => (int)$package['reward_xu'],
                    'reward_luong' => (int)$package['reward_luong'],
                    'reward_luong_khoa' => (int)$package['reward_luong_khoa'],
                    'items' => $package['items'],
                    'description' => $package['description'],
                    'image_url' => $package['image_url'],
                    'is_hot' => (bool)$package['is_hot'],
                    'discount_percent' => (int)$package['discount_percent']
                ]
            ];
            
        } catch (Exception $e) {
            error_log("Error getting package: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Lỗi khi lấy thông tin gói: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Tạo order mua gói (tự động hủy order pending cũ)
     */
    /**
 * Tạo order mua gói (tự động hủy order pending cũ)
 */
public function createPackageOrder($playerName, $serverId, $packageId) {
    try {
        // Lấy thông tin gói
        $packageResult = $this->getPackageById($packageId);
        if (!$packageResult['success']) {
            return $packageResult;
        }
        
        $package = $packageResult['data'];
        
        // Lấy userId từ player name
        $userInfo = $this->getUserIdFromPlayerName($playerName, $serverId);
        if (!$userInfo['success']) {
            return [
                'success' => false,
                'message' => 'Nhân vật không tồn tại trong game'
            ];
        }
        
        $userId = $userInfo['user_id'];
        
        // ✅ KIỂM TRA GIỚI HẠN MUA DựA VÀO max_total_purchase
        // Lấy max_total_purchase từ database
        $limitStmt = $this->accountDb->prepare("
            SELECT max_total_purchase 
            FROM recharge_packages 
            WHERE id = ?
        ");
        $limitStmt->execute([$packageId]);
        $maxPurchase = (int)$limitStmt->fetchColumn();
        
        // Nếu max_total_purchase > 0, kiểm tra số lần đã mua
        if ($maxPurchase > 0) {
            $checkStmt = $this->accountDb->prepare("
                SELECT COUNT(*) as count 
                FROM package_purchase_history 
                WHERE player_name = ? 
                AND server_id = ?
                AND package_code = ?
            ");
            
            $checkStmt->execute([
                $playerName,
                $serverId,
                $package['package_code']
            ]);
            
            $purchaseCount = (int)$checkStmt->fetchColumn();
            
            if ($purchaseCount >= $maxPurchase) {
                return [
                    'success' => false,
                    'message' => "Gói này chỉ được mua tối đa {$maxPurchase} lần cho mỗi nhân vật. Bạn đã mua {$purchaseCount} lần."
                ];
            }
        }
        // Nếu max_total_purchase = 0, không giới hạn
        
        // Tự động hủy tất cả order pending cũ của player này
        $cancelStmt = $this->accountDb->prepare("
            UPDATE package_orders 
            SET status = 'cancelled',
                updated_at = NOW()
            WHERE player_name = ? 
            AND server_id = ?
            AND status = 'pending'
        ");
        $cancelledCount = 0;
        if ($cancelStmt->execute([$playerName, $serverId])) {
            $cancelledCount = $cancelStmt->rowCount();
        }
        
        // Tạo order ID
        $orderId = 'PKG_' . date('YmdHis') . '_' . $playerName;
        
        // Tạo nội dung chuyển khoản: package_code + playerName (KHÔNG có dấu gạch dưới)
        $description = "{$package['package_code']} {$playerName}";
        
        // Tạo QR code
        $qrUrl = "https://qr.sepay.vn/img?" . http_build_query([
            'acc' => $this->config->get('vietqr_account'),
            'bank' => $this->config->get('vietqr_bank'),
            'amount' => $package['price'],
            'des' => $description,
            'template' => 'compact'
        ]);
        
        // Lưu order
        $stmt = $this->accountDb->prepare("
            INSERT INTO package_orders 
            (order_id, user_id, player_name, server_id, package_id, package_code, 
             package_name, price, reward_xu, reward_luong, reward_luong_khoa, 
             items, qr_code_url, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
        ");
        
        $stmt->execute([
            $orderId,
            $userId,
            $playerName,
            $serverId,
            $package['id'],
            $package['package_code'],
            $package['package_name'],
            $package['price'],
            $package['reward_xu'],
            $package['reward_luong'],
            $package['reward_luong_khoa'],
            $package['items'],
            $qrUrl
        ]);
        
        $message = 'Tạo đơn hàng thành công';
        if ($cancelledCount > 0) {
            $message .= " (Đã tự động hủy {$cancelledCount} đơn hàng cũ chưa thanh toán)";
        }
        
        return [
            'success' => true,
            'message' => $message,
            'data' => [
                'order_id' => $orderId,
                'user_id' => $userId,
                'player_name' => $playerName,
                'server_id' => $serverId,
                'package_code' => $package['package_code'],
                'package_name' => $package['package_name'],
                'price' => $package['price'],
                'description' => $package['description'],
                'qr_code_url' => $qrUrl,
                'transfer_description' => $description,
                'bank_info' => [
                    'account_number' => $this->config->get('vietqr_account'),
                    'bank_name' => $this->config->get('vietqr_bank_name'),
                    'account_name' => $this->config->get('vietqr_account_name')
                ],
                'expires_at' => date('Y-m-d H:i:s', strtotime('+30 minutes')),
                'cancelled_old_orders' => $cancelledCount,
                'instructions' => [
                    '1. Quét mã QR hoặc chuyển khoản đến số tài khoản trên',
                    '2. Số tiền: ' . number_format($package['price']) . ' VNĐ',
                    '3. Nội dung chuyển khoản: ' . $description,
                    '4. Sau khi chuyển khoản, hệ thống sẽ tự động xử lý trong 5-10 phút',
                    '5. Phần thưởng: ' . $package['package_name']
                ]
            ]
        ];
        
    } catch (Exception $e) {
        error_log("Create package order error: " . $e->getMessage());
        return [
            'success' => false,
            'message' => 'Lỗi khi tạo đơn hàng: ' . $e->getMessage()
        ];
    }
}
    /**
     * Xử lý thanh toán gói (được gọi từ webhook)
     */
    public function processPackagePurchase($orderId, $transactionId, $bankName, $paymentTime) {
        try {
            $this->accountDb->beginTransaction();
            
            // Lấy thông tin order
            $stmt = $this->accountDb->prepare("
                SELECT * FROM package_orders 
                WHERE order_id = ? 
                AND status = 'pending'
                LIMIT 1
            ");
            $stmt->execute([$orderId]);
            $order = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$order) {
                $this->accountDb->rollBack();
                return [
                    'success' => false,
                    'message' => 'Order không tồn tại hoặc đã xử lý'
                ];
            }
            
            // Cập nhật order status = paid
            $updateStmt = $this->accountDb->prepare("
                UPDATE package_orders 
                SET status = 'paid',
                    transaction_id = ?,
                    bank_name = ?,
                    payment_time = ?,
                    updated_at = NOW()
                WHERE order_id = ?
            ");
            $updateStmt->execute([$transactionId, $bankName, $paymentTime, $orderId]);
            
            // Thêm phần thưởng vào game - BẢNG board_package_rewards
            $gameDb = $this->getGameDb($order['server_id']);
            
            // ✅ SỬA: Dùng board_package_rewards với cột luongKhoa (viết hoa K)
            $rewardStmt = $gameDb->prepare("
                INSERT INTO board_package_rewards 
                (username, xu, luong, luongKhoa, item, package_name, package_code, status, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, 0, NOW())
            ");
            
            $rewardStmt->execute([
                $order['user_id'], // username field lưu userId
                $order['reward_xu'],
                $order['reward_luong'],
                $order['reward_luong_khoa'],
                $order['items'],
                $order['package_name'],
                $order['package_code']
                // status = 0 (chưa nhận)
            ]);
            
            // Cập nhật order status = completed
            $completeStmt = $this->accountDb->prepare("
                UPDATE package_orders 
                SET status = 'completed',
                    updated_at = NOW()
                WHERE order_id = ?
            ");
            $completeStmt->execute([$orderId]);
            
            // Lưu vào lịch sử
            $historyStmt = $this->accountDb->prepare("
                INSERT INTO package_purchase_history 
                (order_id, user_id, player_name, server_id, package_code, package_name, 
                 price, rewards, transaction_id) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $rewards = json_encode([
                'xu' => $order['reward_xu'],
                'luong' => $order['reward_luong'],
                'luong_khoa' => $order['reward_luong_khoa'],
                'items' => $order['items']
            ]);
            
            $historyStmt->execute([
                $orderId,
                $order['user_id'],
                $order['player_name'],
                $order['server_id'],
                $order['package_code'],
                $order['package_name'],
                $order['price'],
                $rewards,
                $transactionId
            ]);
            
            // Cập nhật topnap (KHÔNG tính vào tổng nạp milestone)
            // Nếu muốn tính thì uncomment dòng này:
            // $this->updateTopNap($order['user_id'], $order['player_name'], $order['server_id'], $order['price'], $order['reward_xu'], $order['reward_luong'], $order['reward_luong_khoa'], 1);
            
            $this->accountDb->commit();
            
            return [
                'success' => true,
                'message' => 'Mua gói thành công',
                'data' => [
                    'order_id' => $orderId,
                    'package_name' => $order['package_name'],
                    'rewards' => json_decode($rewards, true),
                    'completed_at' => date('Y-m-d H:i:s')
                ]
            ];
            
        } catch (Exception $e) {
            $this->accountDb->rollBack();
            error_log("Process package purchase error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Lỗi khi xử lý mua gói: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Lấy lịch sử mua gói
     */
    public function getPurchaseHistory($playerName, $serverId = null, $page = 1, $limit = 10) {
        try {
            $offset = ($page - 1) * $limit;
            
            $sql = "SELECT * FROM package_purchase_history WHERE player_name = ?";
            $params = [$playerName];
            
            if ($serverId !== null) {
                $sql .= " AND server_id = ?";
                $params[] = $serverId;
            }
            
            $sql .= " ORDER BY purchased_at DESC LIMIT ? OFFSET ?";
            
            $stmt = $this->accountDb->prepare($sql);
            foreach ($params as $i => $value) {
                $stmt->bindValue($i + 1, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
            }
            $stmt->bindValue(count($params) + 1, $limit, PDO::PARAM_INT);
            $stmt->bindValue(count($params) + 2, $offset, PDO::PARAM_INT);
            $stmt->execute();
            
            $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Parse rewards JSON
            foreach ($history as &$item) {
                $item['rewards'] = json_decode($item['rewards'], true);
            }
            
            // Count total
            $countSql = "SELECT COUNT(*) as total FROM package_purchase_history WHERE player_name = ?";
            $countParams = [$playerName];
            
            if ($serverId !== null) {
                $countSql .= " AND server_id = ?";
                $countParams[] = $serverId;
            }
            
            $countStmt = $this->accountDb->prepare($countSql);
            $countStmt->execute($countParams);
            $total = (int)$countStmt->fetchColumn();
            
            return [
                'success' => true,
                'data' => [
                    'history' => $history,
                    'pagination' => [
                        'page' => $page,
                        'limit' => $limit,
                        'total' => $total,
                        'total_pages' => ceil($total / $limit)
                    ]
                ]
            ];
            
        } catch (Exception $e) {
            error_log("Get purchase history error: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Lỗi khi lấy lịch sử: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Parse item string
     */
    private function parseItemString($itemString) {
        if (empty($itemString)) {
            return [];
        }
        
        $items = [];
        $itemParts = explode(',', $itemString);
        
        foreach ($itemParts as $itemPart) {
            $parts = explode(':', trim($itemPart));
            if (count($parts) >= 4) {
                $items[] = [
                    'type' => $parts[0],
                    'id' => (int)$parts[1],
                    'quantity' => (int)$parts[2],
                    'expire' => (int)$parts[3]
                ];
            }
        }
        
        return $items;
    }
    
    /**
     * Encode item array to string
     */
    private function encodeItemString($items) {
        if (empty($items)) {
            return '';
        }
        
        $parts = [];
        foreach ($items as $item) {
            $parts[] = sprintf(
                '%s:%d:%d:%d',
                $item['type'],
                $item['id'],
                $item['quantity'],
                $item['expire']
            );
        }
        
        return implode(',', $parts);
    }
    
    /**
     * Lấy game DB connection
     */
    private function getGameDb($serverId = 1) {
        if (!isset($this->gameDbs[$serverId])) {
            $dbInstance = Database::getGameInstance($serverId);
            $this->gameDbs[$serverId] = $dbInstance->getConnection();
        }
        
        return $this->gameDbs[$serverId];
    }
}