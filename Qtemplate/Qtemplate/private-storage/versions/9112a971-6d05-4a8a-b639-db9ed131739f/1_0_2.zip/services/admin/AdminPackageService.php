<?php
// services/admin/AdminPackageService.php

class AdminPackageService {
    private $accountDb;
    
    public function __construct() {
        $this->accountDb = Database::getInstance()->getConnection();
    }
    
    /**
     * Get game database connection for specific server
     */
    private function getGameDb($serverId) {
        try {
            return Database::getGameInstance($serverId)->getConnection();
        } catch (Exception $e) {
            throw new Exception("Không thể kết nối database server $serverId: " . $e->getMessage());
        }
    }
    
    /**
     * Lấy danh sách gói nạp với phân trang và lọc
     */
  public function getPackages($page, $limit, $search, $status) {
    $offset = ($page - 1) * $limit;
    
    // Build query
    $where = "1=1";
    $params = [];
    
    // Search filter
    if (!empty($search)) {
        $where .= " AND (package_code LIKE ? OR package_name LIKE ? OR description LIKE ?)";
        $searchTerm = "%$search%";
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $params[] = $searchTerm;
    }
    
    // Status filter
    if ($status === 'active') {
        $where .= " AND is_active = 1";
    } elseif ($status === 'inactive') {
        $where .= " AND is_active = 0";
    }
    
    // Get total count
    $countSql = "SELECT COUNT(*) as total FROM recharge_packages WHERE $where";
    $stmt = $this->accountDb->prepare($countSql);
    $stmt->execute($params);
    $total = $stmt->fetch()['total'];
    
    // Get packages with purchase count
    $sql = "SELECT p.*, 
            COUNT(DISTINCT o.id) as total_purchases,
            COALESCE(SUM(o.price), 0) as total_revenue
            FROM recharge_packages p
            LEFT JOIN package_orders o ON p.id = o.package_id AND o.status = 'completed'
            WHERE $where 
            GROUP BY p.id
            ORDER BY p.display_order ASC, p.id DESC
            LIMIT $limit OFFSET $offset";
    
    $stmt = $this->accountDb->prepare($sql);
    $stmt->execute($params);
    $packages = $stmt->fetchAll();
    
    // Format data
    foreach ($packages as &$package) {
        $package['id'] = (int)$package['id'];
        $package['price'] = (float)$package['price'];
        $package['reward_xu'] = (int)$package['reward_xu'];
        $package['reward_luong'] = (int)$package['reward_luong'];
        $package['reward_luong_khoa'] = (int)$package['reward_luong_khoa'];
        $package['display_order'] = (int)$package['display_order'];
        $package['is_active'] = (int)$package['is_active'];
        $package['is_hot'] = (int)$package['is_hot'];
        $package['discount_percent'] = (int)$package['discount_percent'];
        $package['max_total_purchase'] = (int)$package['max_total_purchase']; // ✅ THÊM
        $package['total_purchases'] = (int)$package['total_purchases'];
        $package['total_revenue'] = (float)$package['total_revenue'];
    }
    
    return [
        'packages' => $packages,
        'pagination' => [
            'total' => (int)$total,
            'page' => $page,
            'limit' => $limit,
            'total_pages' => ceil($total / $limit)
        ]
    ];
}
    /**
     * Lấy chi tiết gói nạp
     */
   public function getPackageDetail($id) {
    $sql = "SELECT p.*, 
            COUNT(DISTINCT o.id) as total_purchases,
            COALESCE(SUM(o.price), 0) as total_revenue,
            COUNT(DISTINCT o.user_id) as unique_buyers
            FROM recharge_packages p
            LEFT JOIN package_orders o ON p.id = o.package_id AND o.status = 'completed'
            WHERE p.id = ?
            GROUP BY p.id";
    
    $stmt = $this->accountDb->prepare($sql);
    $stmt->execute([$id]);
    $package = $stmt->fetch();
    
    if (!$package) {
        return null;
    }
    
    // Format data
    $package['id'] = (int)$package['id'];
    $package['price'] = (float)$package['price'];
    $package['reward_xu'] = (int)$package['reward_xu'];
    $package['reward_luong'] = (int)$package['reward_luong'];
    $package['reward_luong_khoa'] = (int)$package['reward_luong_khoa'];
    $package['display_order'] = (int)$package['display_order'];
    $package['is_active'] = (int)$package['is_active'];
    $package['is_hot'] = (int)$package['is_hot'];
    $package['discount_percent'] = (int)$package['discount_percent'];
    $package['max_total_purchase'] = (int)$package['max_total_purchase']; // ✅ THÊM
    $package['total_purchases'] = (int)$package['total_purchases'];
    $package['total_revenue'] = (float)$package['total_revenue'];
    $package['unique_buyers'] = (int)$package['unique_buyers'];
    
    return $package;
}
    
    /**
     * Tạo gói nạp mới
     */
    public function createPackage($data) {
    // Validate
    $errors = $this->validatePackageData($data);
    if (!empty($errors)) {
        return ['success' => false, 'errors' => $errors];
    }
    
    // Check if package_code exists
    $stmt = $this->accountDb->prepare("SELECT id FROM recharge_packages WHERE package_code = ?");
    $stmt->execute([$data['package_code']]);
    if ($stmt->fetch()) {
        return ['success' => false, 'message' => 'Mã gói đã tồn tại'];
    }
    
    try {
        $sql = "INSERT INTO recharge_packages 
                (package_code, package_name, price, reward_xu, reward_luong, reward_luong_khoa, 
                 items, description, image_url, display_order, is_active, is_hot, discount_percent, 
                 max_total_purchase, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        
        $stmt = $this->accountDb->prepare($sql);
        $stmt->execute([
            $data['package_code'],
            $data['package_name'],
            $data['price'],
            $data['reward_xu'] ?? 0,
            $data['reward_luong'] ?? 0,
            $data['reward_luong_khoa'] ?? 0,
            $data['items'] ?? null,
            $data['description'] ?? '',
            $data['image_url'] ?? null,
            $data['display_order'] ?? 0,
            $data['is_active'] ?? 1,
            $data['is_hot'] ?? 0,
            $data['discount_percent'] ?? 0,
            $data['max_total_purchase'] ?? 0 // ✅ THÊM
        ]);
        
        $id = $this->accountDb->lastInsertId();
        
        return [
            'success' => true,
            'package' => $this->getPackageDetail($id)
        ];
    } catch (PDOException $e) {
        return ['success' => false, 'message' => 'Tạo gói nạp thất bại: ' . $e->getMessage()];
    }
}
    /**
     * Cập nhật gói nạp
     */
   public function updatePackage($id, $data) {
    // Check if exists
    $package = $this->getPackageDetail($id);
    if (!$package) {
        return ['success' => false, 'message' => 'Gói nạp không tồn tại'];
    }
    
    try {
        $updateFields = [];
        $params = [];
        
        if (isset($data['package_code'])) {
            // Check duplicate
            $stmt = $this->accountDb->prepare("SELECT id FROM recharge_packages WHERE package_code = ? AND id != ?");
            $stmt->execute([$data['package_code'], $id]);
            if ($stmt->fetch()) {
                return ['success' => false, 'message' => 'Mã gói đã tồn tại'];
            }
            $updateFields[] = "package_code = ?";
            $params[] = $data['package_code'];
        }
        
        if (isset($data['package_name'])) {
            $updateFields[] = "package_name = ?";
            $params[] = $data['package_name'];
        }
        
        if (isset($data['price'])) {
            $updateFields[] = "price = ?";
            $params[] = $data['price'];
        }
        
        if (isset($data['reward_xu'])) {
            $updateFields[] = "reward_xu = ?";
            $params[] = $data['reward_xu'];
        }
        
        if (isset($data['reward_luong'])) {
            $updateFields[] = "reward_luong = ?";
            $params[] = $data['reward_luong'];
        }
        
        if (isset($data['reward_luong_khoa'])) {
            $updateFields[] = "reward_luong_khoa = ?";
            $params[] = $data['reward_luong_khoa'];
        }
        
        if (isset($data['items'])) {
            $updateFields[] = "items = ?";
            $params[] = $data['items'];
        }
        
        if (isset($data['description'])) {
            $updateFields[] = "description = ?";
            $params[] = $data['description'];
        }
        
        if (isset($data['image_url'])) {
            $updateFields[] = "image_url = ?";
            $params[] = $data['image_url'];
        }
        
        if (isset($data['display_order'])) {
            $updateFields[] = "display_order = ?";
            $params[] = $data['display_order'];
        }
        
        if (isset($data['is_active'])) {
            $updateFields[] = "is_active = ?";
            $params[] = $data['is_active'];
        }
        
        if (isset($data['is_hot'])) {
            $updateFields[] = "is_hot = ?";
            $params[] = $data['is_hot'];
        }
        
        if (isset($data['discount_percent'])) {
            $updateFields[] = "discount_percent = ?";
            $params[] = $data['discount_percent'];
        }
        
        // ✅ THÊM: Hỗ trợ cập nhật max_total_purchase
        if (isset($data['max_total_purchase'])) {
            $updateFields[] = "max_total_purchase = ?";
            $params[] = $data['max_total_purchase'];
        }
        
        if (empty($updateFields)) {
            return ['success' => false, 'message' => 'Không có dữ liệu để cập nhật'];
        }
        
        $updateFields[] = "updated_at = NOW()";
        $params[] = $id;
        
        $sql = "UPDATE recharge_packages SET " . implode(', ', $updateFields) . " WHERE id = ?";
        $stmt = $this->accountDb->prepare($sql);
        $stmt->execute($params);
        
        return [
            'success' => true,
            'package' => $this->getPackageDetail($id)
        ];
    } catch (PDOException $e) {
        return ['success' => false, 'message' => 'Cập nhật thất bại: ' . $e->getMessage()];
    }
}
    
    /**
     * Xóa gói nạp
     */
    public function deletePackage($id) {
        try {
            $this->accountDb->beginTransaction();
            
            // Kiểm tra có orders đang pending không
            $stmt = $this->accountDb->prepare("
                SELECT COUNT(*) as count 
                FROM package_orders 
                WHERE package_id = ? AND status = 'pending'
            ");
            $stmt->execute([$id]);
            $pendingCount = $stmt->fetch()['count'];
            
            if ($pendingCount > 0) {
                $this->accountDb->rollBack();
                return ['success' => false, 'message' => 'Không thể xóa gói có đơn hàng đang chờ xử lý'];
            }
            
            // Xóa gói (giữ lại orders history)
            $stmt = $this->accountDb->prepare("DELETE FROM recharge_packages WHERE id = ?");
            $stmt->execute([$id]);
            
            if ($stmt->rowCount() === 0) {
                $this->accountDb->rollBack();
                return ['success' => false, 'message' => 'Gói nạp không tồn tại'];
            }
            
            $this->accountDb->commit();
            return ['success' => true];
        } catch (PDOException $e) {
            $this->accountDb->rollBack();
            return ['success' => false, 'message' => 'Xóa thất bại: ' . $e->getMessage()];
        }
    }
    
    /**
     * Lấy lịch sử mua của gói
     */
    public function getPackagePurchaseLog($packageId, $page, $limit, $status = null) {
        $offset = ($page - 1) * $limit;
        
        // Check if package exists
        $stmt = $this->accountDb->prepare("SELECT id, package_code, package_name FROM recharge_packages WHERE id = ?");
        $stmt->execute([$packageId]);
        $package = $stmt->fetch();
        
        if (!$package) {
            return null;
        }
        
        // Build where
        $where = "package_id = ?";
        $params = [$packageId];
        
        if ($status) {
            $where .= " AND status = ?";
            $params[] = $status;
        }
        
        // Count
        $stmt = $this->accountDb->prepare("SELECT COUNT(*) as total FROM package_orders WHERE $where");
        $stmt->execute($params);
        $total = $stmt->fetch()['total'];
        
        // Get logs
        $sql = "SELECT * FROM package_orders 
                WHERE $where 
                ORDER BY created_at DESC 
                LIMIT $limit OFFSET $offset";
        
        $stmt = $this->accountDb->prepare($sql);
        $stmt->execute($params);
        $logs = $stmt->fetchAll();
        
        // Format
        foreach ($logs as &$log) {
            $log['id'] = (int)$log['id'];
            $log['user_id'] = (int)$log['user_id'];
            $log['server_id'] = (int)$log['server_id'];
            $log['package_id'] = (int)$log['package_id'];
            $log['price'] = (float)$log['price'];
            $log['reward_xu'] = (int)$log['reward_xu'];
            $log['reward_luong'] = (int)$log['reward_luong'];
            $log['reward_luong_khoa'] = (int)$log['reward_luong_khoa'];
        }
        
        return [
            'package_id' => (int)$packageId,
            'package_code' => $package['package_code'],
            'package_name' => $package['package_name'],
            'logs' => $logs,
            'pagination' => [
                'total' => (int)$total,
                'page' => $page,
                'limit' => $limit,
                'total_pages' => ceil($total / $limit)
            ]
        ];
    }
    
    /**
     * Thống kê gói nạp
     */
    public function getPackageStats() {
        // Total packages
        $stmt = $this->accountDb->query("SELECT COUNT(*) as total FROM recharge_packages");
        $totalPackages = $stmt->fetch()['total'];
        
        // Active packages
        $stmt = $this->accountDb->query("SELECT COUNT(*) as total FROM recharge_packages WHERE is_active = 1");
        $activePackages = $stmt->fetch()['total'];
        
        // Inactive packages
        $stmt = $this->accountDb->query("SELECT COUNT(*) as total FROM recharge_packages WHERE is_active = 0");
        $inactivePackages = $stmt->fetch()['total'];
        
        // Total orders
        $stmt = $this->accountDb->query("SELECT COUNT(*) as total FROM package_orders");
        $totalOrders = $stmt->fetch()['total'];
        
        // Completed orders
        $stmt = $this->accountDb->query("SELECT COUNT(*) as total FROM package_orders WHERE status = 'completed'");
        $completedOrders = $stmt->fetch()['total'];
        
        // Pending orders
        $stmt = $this->accountDb->query("SELECT COUNT(*) as total FROM package_orders WHERE status = 'pending'");
        $pendingOrders = $stmt->fetch()['total'];
        
        // Total revenue
        $stmt = $this->accountDb->query("SELECT COALESCE(SUM(price), 0) as total FROM package_orders WHERE status = 'completed'");
        $totalRevenue = $stmt->fetch()['total'];
        
        // Unique buyers
        $stmt = $this->accountDb->query("SELECT COUNT(DISTINCT user_id) as total FROM package_orders WHERE status = 'completed'");
        $uniqueBuyers = $stmt->fetch()['total'];
        
        // Best selling packages
        $stmt = $this->accountDb->query("
            SELECT p.id, p.package_code, p.package_name, p.price,
                   COUNT(o.id) as total_sold,
                   SUM(o.price) as revenue
            FROM recharge_packages p
            LEFT JOIN package_orders o ON p.id = o.package_id AND o.status = 'completed'
            GROUP BY p.id
            ORDER BY total_sold DESC
            LIMIT 10
        ");
        $bestSelling = $stmt->fetchAll();
        
        // Recent orders (last 7 days)
        $stmt = $this->accountDb->query("
            SELECT DATE(created_at) as date, 
                   COUNT(*) as count,
                   SUM(price) as revenue
            FROM package_orders
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
              AND status = 'completed'
            GROUP BY DATE(created_at)
            ORDER BY date DESC
        ");
        $recentOrders = $stmt->fetchAll();
        
        // Orders by status
        $stmt = $this->accountDb->query("
            SELECT status, COUNT(*) as count
            FROM package_orders
            GROUP BY status
            ORDER BY count DESC
        ");
        $byStatus = $stmt->fetchAll();
        
        // Orders by server
        $stmt = $this->accountDb->query("
            SELECT server_id, COUNT(*) as count, SUM(price) as revenue
            FROM package_orders
            WHERE status = 'completed'
            GROUP BY server_id
            ORDER BY count DESC
        ");
        $byServer = $stmt->fetchAll();
        
        return [
            'total_packages' => (int)$totalPackages,
            'active_packages' => (int)$activePackages,
            'inactive_packages' => (int)$inactivePackages,
            'total_orders' => (int)$totalOrders,
            'completed_orders' => (int)$completedOrders,
            'pending_orders' => (int)$pendingOrders,
            'total_revenue' => (float)$totalRevenue,
            'unique_buyers' => (int)$uniqueBuyers,
            'best_selling' => $bestSelling,
            'recent_orders' => $recentOrders,
            'by_status' => $byStatus,
            'by_server' => $byServer
        ];
    }
    
    /**
     * Lấy danh sách users đã mua gói
     */
    public function getPackageBuyers($packageId, $serverId = null, $page = 1, $limit = 20) {
        $offset = ($page - 1) * $limit;
        
        $where = "o.package_id = ? AND o.status = 'completed'";
        $params = [$packageId];
        
        if ($serverId) {
            $where .= " AND o.server_id = ?";
            $params[] = $serverId;
        }
        
        // Count
        $countSql = "SELECT COUNT(*) as total FROM package_orders o WHERE $where";
        $stmt = $this->accountDb->prepare($countSql);
        $stmt->execute($params);
        $total = $stmt->fetch()['total'];
        
        // Get buyers with topnap info
        $sql = "SELECT o.*, t.total_amount, t.total_recharge
                FROM package_orders o
                LEFT JOIN topnap t ON o.user_id = t.user_id AND o.server_id = t.server_id
                WHERE $where
                ORDER BY o.created_at DESC
                LIMIT $limit OFFSET $offset";
        
        $stmt = $this->accountDb->prepare($sql);
        $stmt->execute($params);
        $buyers = $stmt->fetchAll();
        
        return [
            'package_id' => (int)$packageId,
            'buyers' => $buyers,
            'pagination' => [
                'total' => (int)$total,
                'page' => $page,
                'limit' => $limit,
                'total_pages' => ceil($total / $limit)
            ]
        ];
    }
    
    /**
     * Export packages to CSV
     */
   public function exportPackages($search, $status) {
    $where = "1=1";
    $params = [];
    
    if (!empty($search)) {
        $where .= " AND (package_code LIKE ? OR package_name LIKE ? OR description LIKE ?)";
        $searchTerm = "%$search%";
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $params[] = $searchTerm;
    }
    
    if ($status === 'active') {
        $where .= " AND is_active = 1";
    } elseif ($status === 'inactive') {
        $where .= " AND is_active = 0";
    }
    
    $sql = "SELECT p.*, 
            COUNT(DISTINCT o.id) as total_purchases,
            COALESCE(SUM(o.price), 0) as total_revenue
            FROM recharge_packages p
            LEFT JOIN package_orders o ON p.id = o.package_id AND o.status = 'completed'
            WHERE $where 
            GROUP BY p.id
            ORDER BY p.display_order ASC, p.id DESC";
    
    $stmt = $this->accountDb->prepare($sql);
    $stmt->execute($params);
    $packages = $stmt->fetchAll();
    
    // Create CSV
    $output = fopen('php://temp', 'r+');
    
    // Header - ✅ THÊM cột "Giới hạn mua"
    fputcsv($output, [
        'ID', 'Mã gói', 'Tên gói', 'Giá', 'Xu', 'Lượng', 'Lượng Khóa', 
        'Items', 'Mô tả', 'Hot', 'Giảm giá (%)', 'Giới hạn mua', 'Thứ tự', 'Trạng thái', 
        'Đã bán', 'Doanh thu'
    ]);
    
    // Data - ✅ THÊM giá trị max_total_purchase
    foreach ($packages as $p) {
        fputcsv($output, [
            $p['id'],
            $p['package_code'],
            $p['package_name'],
            $p['price'],
            $p['reward_xu'],
            $p['reward_luong'],
            $p['reward_luong_khoa'],
            $p['items'],
            $p['description'],
            $p['is_hot'] ? 'Yes' : 'No',
            $p['discount_percent'],
            $p['max_total_purchase'] == 0 ? 'Unlimited' : $p['max_total_purchase'], // ✅ THÊM
            $p['display_order'],
            $p['is_active'] ? 'Active' : 'Inactive',
            $p['total_purchases'],
            $p['total_revenue']
        ]);
    }
    
    rewind($output);
    $csv = stream_get_contents($output);
    fclose($output);
    
    return $csv;
}
    
    /**
     * Xóa hàng loạt
     */
    public function bulkDelete($packageIds) {
        if (empty($packageIds) || !is_array($packageIds)) {
            return ['success' => false, 'message' => 'Danh sách ID không hợp lệ'];
        }
        
        try {
            $this->accountDb->beginTransaction();
            
            // Kiểm tra pending orders
            $placeholders = implode(',', array_fill(0, count($packageIds), '?'));
            $stmt = $this->accountDb->prepare("
                SELECT COUNT(*) as count 
                FROM package_orders 
                WHERE package_id IN ($placeholders) AND status = 'pending'
            ");
            $stmt->execute($packageIds);
            $pendingCount = $stmt->fetch()['count'];
            
            if ($pendingCount > 0) {
                $this->accountDb->rollBack();
                return ['success' => false, 'message' => 'Không thể xóa gói có đơn hàng đang chờ xử lý'];
            }
            
            // Delete packages
            $sql = "DELETE FROM recharge_packages WHERE id IN ($placeholders)";
            $stmt = $this->accountDb->prepare($sql);
            $stmt->execute($packageIds);
            
            $deletedCount = $stmt->rowCount();
            
            $this->accountDb->commit();
            
            return [
                'success' => true,
                'deleted_count' => $deletedCount
            ];
        } catch (PDOException $e) {
            $this->accountDb->rollBack();
            return ['success' => false, 'message' => 'Xóa thất bại: ' . $e->getMessage()];
        }
    }
    
    /**
     * Toggle active status
     */
    public function toggleActive($id) {
        try {
            $package = $this->getPackageDetail($id);
            if (!$package) {
                return ['success' => false, 'message' => 'Gói nạp không tồn tại'];
            }
            
            $newStatus = $package['is_active'] ? 0 : 1;
            
            $stmt = $this->accountDb->prepare("UPDATE recharge_packages SET is_active = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$newStatus, $id]);
            
            return [
                'success' => true,
                'package' => $this->getPackageDetail($id)
            ];
        } catch (PDOException $e) {
            return ['success' => false, 'message' => 'Cập nhật thất bại: ' . $e->getMessage()];
        }
    }
    
    /**
     * Toggle hot status
     */
    public function toggleHot($id) {
        try {
            $package = $this->getPackageDetail($id);
            if (!$package) {
                return ['success' => false, 'message' => 'Gói nạp không tồn tại'];
            }
            
            $newStatus = $package['is_hot'] ? 0 : 1;
            
            $stmt = $this->accountDb->prepare("UPDATE recharge_packages SET is_hot = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$newStatus, $id]);
            
            return [
                'success' => true,
                'package' => $this->getPackageDetail($id)
            ];
        } catch (PDOException $e) {
            return ['success' => false, 'message' => 'Cập nhật thất bại: ' . $e->getMessage()];
        }
    }
    
    // Helper methods
    
    private function validatePackageData($data) {
        $errors = [];
        
        if (empty($data['package_code'])) {
            $errors['package_code'] = 'Mã gói không được để trống';
        }
        
        if (empty($data['package_name'])) {
            $errors['package_name'] = 'Tên gói không được để trống';
        }
        
        if (empty($data['price']) || $data['price'] <= 0) {
            $errors['price'] = 'Giá gói không hợp lệ';
        }
        
        if (!isset($data['reward_xu']) && !isset($data['reward_luong']) && !isset($data['reward_luong_khoa']) && empty($data['items'])) {
            $errors['rewards'] = 'Gói nạp phải có ít nhất một phần thưởng';
        }
        
        return $errors;
    }
}