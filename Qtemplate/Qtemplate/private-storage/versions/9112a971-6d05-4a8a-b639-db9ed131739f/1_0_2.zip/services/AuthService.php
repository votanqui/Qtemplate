<?php
// services/AuthService.php

class AuthService {
    private $remoteDb;  // ✅ Remote DB cho team_user
    private $localDb;   // ✅ Local DB cho team_auth
    
    public function __construct() {
        $this->remoteDb = Database::getRemoteInstance()->getConnection(); // ✅ Remote (team_user)
        $this->localDb = Database::getInstance()->getConnection();        // ✅ Local (team_auth)
    }
    
    public function register($username, $password, $phone, $email = null) {
    $errors = [];
    
    if (empty($username) || strlen($username) < 3 || strlen($username) > 20) {
        $errors['username'] = 'Tên đăng nhập phải từ 3 đến 20 ký tự';
    }
    
    if (empty($password) || strlen($password) < 6) {
        $errors['password'] = 'Mật khẩu phải ít nhất 6 ký tự';
    }
    
    $phoneValidation = $this->validateAndNormalizePhone($phone);
    if (!$phoneValidation['valid']) {
        $errors['phone'] = $phoneValidation['message'];
    } else {
        $phone = $phoneValidation['normalized'];
    }
    
    $emailValidation = $this->validateEmail($email);
    if (!$emailValidation['valid']) {
        $errors['email'] = $emailValidation['message'];
    }
    
    if (!empty($errors)) {
        return ['success' => false, 'errors' => $errors];
    }
    
    // ✅ Check username trên REMOTE DB
    $stmt = $this->remoteDb->prepare("SELECT id FROM team_user WHERE username = ?");
    $stmt->execute([$username]);
    
    if ($stmt->fetch()) {
        return ['success' => false, 'errors' => ['username' => 'Tên đăng nhập đã tồn tại']];
    }
    
    // ✅ Check số lượng tài khoản đã đăng ký bằng SĐT này
    $stmt = $this->remoteDb->prepare("SELECT COUNT(*) as count FROM team_user WHERE phone = ?");
    $stmt->execute([$phone]);
    $phoneCount = $stmt->fetch();
    
    if ($phoneCount['count'] >= 5) {
        return ['success' => false, 'errors' => ['phone' => 'Số điện thoại này đã đăng ký tối đa 5 tài khoản']];
    }
    
    // ✅ Check số lượng tài khoản đã đăng ký bằng Email này (nếu có email)
    if (!empty($email)) {
        $stmt = $this->remoteDb->prepare("SELECT COUNT(*) as count FROM team_user WHERE email = ?");
        $stmt->execute([$email]);
        $emailCount = $stmt->fetch();
        
        if ($emailCount['count'] >= 5) {
            return ['success' => false, 'errors' => ['email' => 'Email này đã đăng ký tối đa 5 tài khoản']];
        }
    }
    
    $hashedPassword = '*' . strtoupper(sha1(sha1($password, true)));
    
    // ✅ Insert vào REMOTE DB
    $stmt = $this->remoteDb->prepare("
        INSERT INTO team_user (username, password, phone, email, regdate, ip_addr) 
        VALUES (?, ?, ?, ?, NOW(), ?)
    ");
    
    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? null;
    
    try {
        $stmt->execute([$username, $hashedPassword, $phone, $email, $ipAddress]);
        $userId = $this->remoteDb->lastInsertId();
        
        return [
            'success' => true,
            'user_id' => $userId,
            'username' => $username
        ];
    } catch (PDOException $e) {
        return ['success' => false, 'errors' => ['database' => 'Đăng ký thất bại']];
    }
}
    
    public function login($username, $password) {
        $hashedPassword = '*' . strtoupper(sha1(sha1($password, true)));
        
        // ✅ Get user từ REMOTE DB
        $stmt = $this->remoteDb->prepare("
            SELECT id, username, phone, email, ban, active, isAdmin 
            FROM team_user 
            WHERE username = ? AND password = ?
        ");
        
        $stmt->execute([$username, $hashedPassword]);
        $user = $stmt->fetch();
        
        if (!$user) {
            return ['success' => false, 'message' => 'sai tên đăng nhập hoặc mật khẩu'];
        }
        
        if ($user['ban'] == 1) {
            return ['success' => false, 'message' => 'tài khoản của bạn đã bị khóa'];
        }
        
        $accessToken = JWTHelper::generateAccessToken($user['id']);
        $refreshToken = JWTHelper::generateRefreshToken($user['id']);
        
        // ✅ Save tokens vào LOCAL DB
        $this->saveAuthTokens($user['id'], $accessToken, $refreshToken);
        
        return [
            'success' => true,          
            'tokens' => [
                'access_token' => $accessToken,
                'refresh_token' => $refreshToken,
                'expires_in' => Config::JWT_ACCESS_EXPIRY
            ]
        ];
    }
    
    public function logout($accessToken) {
        // ✅ Deactivate token trên LOCAL DB
        $stmt = $this->localDb->prepare("
            UPDATE team_auth 
            SET is_active = 0, updated_at = NOW() 
            WHERE access_token = ?
        ");
        
        return $stmt->execute([$accessToken]);
    }
    
    public function logoutAll($userId) {
        // ✅ Logout all sessions trên LOCAL DB
        $stmt = $this->localDb->prepare("
            UPDATE team_auth 
            SET is_active = 0, updated_at = NOW() 
            WHERE user_id = ? AND is_active = 1
        ");
        
        return $stmt->execute([$userId]);
    }
    
    public function getActiveSessions($userId) {
        // ✅ Get sessions từ LOCAL DB
        $stmt = $this->localDb->prepare("
            SELECT 
                id,
                ip_address,
                user_agent,
                created_at,
                last_used,
                CASE 
                    WHEN last_used > DATE_SUB(NOW(), INTERVAL 5 MINUTE) THEN 'active'
                    WHEN last_used > DATE_SUB(NOW(), INTERVAL 1 HOUR) THEN 'recent'
                    ELSE 'idle'
                END as status
            FROM team_auth 
            WHERE user_id = ? AND is_active = 1
            ORDER BY last_used DESC
        ");
        
        $stmt->execute([$userId]);
        return $stmt->fetchAll();
    }
    
    public function revokeSession($userId, $sessionId) {
        // ✅ Revoke session trên LOCAL DB
        $stmt = $this->localDb->prepare("
            UPDATE team_auth 
            SET is_active = 0, updated_at = NOW() 
            WHERE id = ? AND user_id = ?
        ");
        
        return $stmt->execute([$sessionId, $userId]);
    }
    
    public function refreshToken($refreshToken) {
        $payload = JWTHelper::validateToken($refreshToken);
        
        if (!$payload || $payload['type'] !== 'refresh') {
            return ['success' => false, 'message' => 'Invalid refresh token'];
        }
        
        // ✅ Check token trên LOCAL DB
        $stmt = $this->localDb->prepare("
            SELECT user_id 
            FROM team_auth 
            WHERE refresh_token = ? AND is_active = 1
        ");
        
        $stmt->execute([$refreshToken]);
        $auth = $stmt->fetch();
        
        if (!$auth) {
            return ['success' => false, 'message' => 'Refresh token not found or inactive'];
        }
        
        $newAccessToken = JWTHelper::generateAccessToken($auth['user_id']);
        
        // ✅ Update token trên LOCAL DB
        $stmt = $this->localDb->prepare("
            UPDATE team_auth 
            SET access_token = ?, access_token_expires = DATE_ADD(NOW(), INTERVAL ? SECOND), updated_at = NOW()
            WHERE refresh_token = ?
        ");
        
        $stmt->execute([$newAccessToken, Config::JWT_ACCESS_EXPIRY, $refreshToken]);
        
        return [
            'success' => true,
            'tokens' => [
                'access_token' => $newAccessToken,
                'expires_in' => Config::JWT_ACCESS_EXPIRY
            ]
        ];
    }
    
    public function changePassword($userId, $currentPassword, $newPassword) {
        if (strlen($newPassword) < 6) {
            return [
                'success' => false,
                'message' => 'Mật khẩu mới phải có ít nhất 6 ký tự'
            ];
        }
        
        if (strlen($newPassword) > 32) {
            return [
                'success' => false,
                'message' => 'Mật khẩu mới không được vượt quá 32 ký tự'
            ];
        }
        
        // ✅ Get user từ REMOTE DB
        $stmt = $this->remoteDb->prepare("SELECT password FROM team_user WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        if (!$user) {
            return [
                'success' => false,
                'message' => 'Không tìm thấy người dùng'
            ];
        }
        
        $hashedCurrentPassword = '*' . strtoupper(sha1(sha1($currentPassword, true)));
        
        if ($user['password'] !== $hashedCurrentPassword) {
            return [
                'success' => false,
                'message' => 'Mật khẩu hiện tại không đúng'
            ];
        }
        
        $hashedNewPassword = '*' . strtoupper(sha1(sha1($newPassword, true)));
        
        if ($user['password'] === $hashedNewPassword) {
            return [
                'success' => false,
                'message' => 'Mật khẩu mới phải khác mật khẩu hiện tại'
            ];
        }
        
        // ✅ Update password trên REMOTE DB
        try {
            $stmt = $this->remoteDb->prepare("UPDATE team_user SET password = ? WHERE id = ?");
            $stmt->execute([$hashedNewPassword, $userId]);
            
            return [
                'success' => true,
                'message' => 'Đổi mật khẩu thành công'
            ];
        } catch (PDOException $e) {
            return [
                'success' => false,
                'message' => 'Đổi mật khẩu thất bại'
            ];
        }
    }
    
    public function getUserInfo($userId) {
        try {
            // ✅ Lấy thông tin user từ REMOTE DB
            $stmt = $this->remoteDb->prepare("
                SELECT id, username, phone, email, ban, active, isAdmin, regdate
                FROM team_user 
                WHERE id = ? 
                LIMIT 1
            ");
            $stmt->execute([$userId]);
            $user = $stmt->fetch();
            
            if (!$user) {
                return [
                    'success' => false,
                    'message' => 'Người dùng không tồn tại'
                ];
            }
            
            $accountActive = $this->checkUserActivation($userId);
            
            return [
                'success' => true,
                'data' => [
                    'id' => (int)$user['id'],
                    'username' => $user['username'],
                    'phone' => $user['phone'],
                    'email' => $user['email'],
                    'isAdmin' => (bool)$user['isAdmin'],
                    'active' => (bool)$user['active'],
                    'account_active' => $accountActive,
                    'regdate' => $user['regdate']
                ]
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Lỗi khi lấy thông tin: ' . $e->getMessage()
            ];
        }
    }
    
    private function checkUserActivation($userId, $serverId = 1) {
        try {
            $gameDb = Database::getGameInstance($serverId)->getConnection();
            
            $stmt = $gameDb->prepare("
                SELECT COUNT(*) as count 
                FROM `5h_active` 
                WHERE `userID` = ? 
                LIMIT 1
            ");
            $stmt->execute([$userId]);
            $result = $stmt->fetch();
            
            return (int)$result['count'] > 0;
            
        } catch (Exception $e) {
            error_log("Check activation error: " . $e->getMessage());
            return false;
        }
    }
    
    public function validateAccessToken($accessToken) {
        $payload = JWTHelper::validateToken($accessToken);
        
        if (!$payload || $payload['type'] !== 'access') {
            http_response_code(401);
            return false;
        }
        
        // ✅ Check token trên LOCAL DB
        $stmt = $this->localDb->prepare("
            SELECT user_id 
            FROM team_auth 
            WHERE access_token = ? AND is_active = 1
        ");
        
        $stmt->execute([$accessToken]);
        
        if (!$stmt->fetch()) {
            return false;
        }
        
        // ✅ Update last used trên LOCAL DB
        $stmt = $this->localDb->prepare("
            UPDATE team_auth 
            SET last_used = NOW() 
            WHERE access_token = ?
        ");
        $stmt->execute([$accessToken]);
        
        return $payload['user_id'];
    }
    
    private function validateAndNormalizePhone($phone) {
        if (empty($phone)) {
            return ['valid' => false, 'message' => 'Số điện thoại là bắt buộc'];
        }
        
        $phone = preg_replace('/[^0-9]/', '', $phone);
        
        if (strlen($phone) < 10 || strlen($phone) > 11) {
            return ['valid' => false, 'message' => 'Số điện thoại phải có 10-11 số'];
        }
        
        $validPrefixes = [
            '03', '05', '07', '08', '09',
            '032', '033', '034', '035', '036', '037', '038', '039',
            '070', '076', '077', '078', '079',
            '081', '082', '083', '084', '085', '086', '087', '088',
            '056', '058', '059',
            '052', '055',
            '091', '094',
            '092', '093',
            '096', '097', '098',
            '086'
        ];
        
        $prefix = substr($phone, 0, 2);
        $prefix3 = substr($phone, 0, 3);
        
        if (!in_array($prefix, $validPrefixes) && !in_array($prefix3, $validPrefixes)) {
            return ['valid' => false, 'message' => 'Đầu số không hợp lệ'];
        }
        
        $digits = str_split($phone);
        
        $isSequential = true;
        for ($i = 1; $i < count($digits); $i++) {
            if ((int)$digits[$i] != (int)$digits[$i-1] + 1) {
                $isSequential = false;
                break;
            }
        }
        
        if ($isSequential) {
            return ['valid' => false, 'message' => 'Số điện thoại không hợp lệ (số tăng dần)'];
        }
        
        $isRepeating = true;
        for ($i = 1; $i < count($digits); $i++) {
            if ($digits[$i] != $digits[0]) {
                $isRepeating = false;
                break;
            }
        }
        
        if ($isRepeating) {
            return ['valid' => false, 'message' => 'Số điện thoại không hợp lệ (số lặp lại)'];
        }
        
        $commonPatterns = [
            '1234567890', '0123456789', '0987654321',
            '1111111111', '2222222222', '3333333333',
            '4444444444', '5555555555', '6666666666',
            '7777777777', '8888888888', '9999999999',
            '0000000000'
        ];
        
        if (in_array($phone, $commonPatterns)) {
            return ['valid' => false, 'message' => 'Số điện thoại không hợp lệ (số dễ đoán)'];
        }
        
        if (strpos($phone, '0') !== 0) {
            if (strpos($phone, '84') === 0) {
                $phone = '0' . substr($phone, 2);
            } else {
                $phone = '0' . $phone;
            }
        }
        
        if (strlen($phone) > 10) {
            $phone = substr($phone, 0, 10);
        }
        
        return [
            'valid' => true, 
            'normalized' => $phone,
            'message' => 'Số điện thoại hợp lệ'
        ];
    }
    
    private function validateEmail($email) {
        if (empty($email)) {
            return ['valid' => true, 'message' => 'Email có thể để trống'];
        }
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['valid' => false, 'message' => 'Email không hợp lệ'];
        }
        
        $spamDomains = [
            'tempmail.com', '10minutemail.com', 'guerrillamail.com',
            'mailinator.com', 'yopmail.com', 'trashmail.com',
            'disposablemail.com', 'fakeinbox.com', 'throwawaymail.com',
            'temp-mail.org', 'getairmail.com', 'meltmail.com',
            'sharklasers.com', 'grr.la', 'guerrillamail.net'
        ];
        
        $domain = strtolower(substr(strrchr($email, "@"), 1));
        
        foreach ($spamDomains as $spamDomain) {
            if (strpos($domain, $spamDomain) !== false) {
                return ['valid' => false, 'message' => 'Email tạm thời không được chấp nhận'];
            }
        }
        
        $username = strtok($email, '@');
        $digitCount = preg_match_all('/\d/', $username);
        $totalLength = strlen($username);
        
        if ($totalLength > 0 && ($digitCount / $totalLength) > 0.5) {
            return ['valid' => false, 'message' => 'Email không hợp lệ (chứa quá nhiều số)'];
        }
        
        $commonPatterns = [
            'test@', 'admin@', 'user@', 'demo@',
            '123456@', 'abcdef@', 'qwerty@'
        ];
        
        foreach ($commonPatterns as $pattern) {
            if (stripos($email, $pattern) === 0) {
                return ['valid' => false, 'message' => 'Email không hợp lệ (email test)'];
            }
        }
        
        return ['valid' => true, 'message' => 'Email hợp lệ'];
    }
    
    private function saveAuthTokens($userId, $accessToken, $refreshToken) {
        $ipAddress = $_SERVER['REMOTE_ADDR'] ?? null;
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? null;
        
        // ✅ Check session trên LOCAL DB
        $stmtCheck = $this->localDb->prepare("
            SELECT id FROM team_auth 
            WHERE user_id = ? AND is_active = 1 
            LIMIT 1
        ");
        $stmtCheck->execute([$userId]);
        $existingSession = $stmtCheck->fetch();
        
        if ($existingSession) {
            // ✅ Update session trên LOCAL DB
            $stmt = $this->localDb->prepare("
                UPDATE team_auth SET
                    access_token = ?,
                    refresh_token = ?,
                    access_token_expires = DATE_ADD(NOW(), INTERVAL ? SECOND),
                    refresh_token_expires = DATE_ADD(NOW(), INTERVAL ? SECOND),
                    ip_address = ?,
                    user_agent = ?,
                    is_active = 1,
                    updated_at = NOW(),
                    last_used = NOW()
                WHERE user_id = ? AND is_active = 1
            ");
            
            $stmt->execute([
                $accessToken,
                $refreshToken,
                Config::JWT_ACCESS_EXPIRY,
                Config::JWT_REFRESH_EXPIRY,
                $ipAddress,
                $userAgent,
                $userId
            ]);
        } else {
            // ✅ Insert session mới vào LOCAL DB
            $stmt = $this->localDb->prepare("
                INSERT INTO team_auth (
                    user_id, access_token, refresh_token, 
                    access_token_expires, refresh_token_expires,
                    ip_address, user_agent, is_active, last_used
                ) VALUES (
                    ?, ?, ?, 
                    DATE_ADD(NOW(), INTERVAL ? SECOND),
                    DATE_ADD(NOW(), INTERVAL ? SECOND),
                    ?, ?, 1, NOW()
                )
            ");
            
            $stmt->execute([
                $userId, 
                $accessToken, 
                $refreshToken,
                Config::JWT_ACCESS_EXPIRY,
                Config::JWT_REFRESH_EXPIRY,
                $ipAddress,
                $userAgent
            ]);
        }
    }
}