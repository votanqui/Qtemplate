<?php
// config/Database.php

class Database {
    private static $localInstance = null;      // ✅ Local DB (localhost)
    private static $remoteInstance = null;     // ✅ Remote DB (14.225.209.87)
    private static $gameInstances = [];
    private static $serverConfigCache = [];
    
    private $connection;
    
    private function __construct($dbConfig) {
        try {
            $dsn = "mysql:host=" . $dbConfig['host'] . 
                   ";dbname=" . $dbConfig['name'] . 
                   ";port=" . $dbConfig['port'] . 
                   ";charset=" . $dbConfig['charset'];
            
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_PERSISTENT => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4",
                PDO::ATTR_TIMEOUT => 5,
            ];
            
            $this->connection = new PDO($dsn, $dbConfig['user'], $dbConfig['pass'], $options);
            
            $this->connection->exec("SET SESSION wait_timeout=300");
            $this->connection->exec("SET SESSION interactive_timeout=300");
            
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            throw new Exception("Database connection failed: " . $e->getMessage());
        }
    }
    
    /**
     * ✅ Get LOCAL Database Instance (localhost) - Dùng cho servers và các bảng khác
     */
    public static function getInstance() {
        if (self::$localInstance === null) {
            $config = [
                'host' => Config::DB_HOST,
                'name' => Config::DB_NAME,
                'user' => Config::DB_USER,
                'pass' => Config::DB_PASS,
                'port' => 3306,
                'charset' => Config::DB_CHARSET
            ];
            self::$localInstance = new self($config);
        }
        
        try {
            self::$localInstance->connection->query('SELECT 1');
        } catch (PDOException $e) {
            error_log("Reconnecting local database...");
            $config = [
                'host' => Config::DB_HOST,
                'name' => Config::DB_NAME,
                'user' => Config::DB_USER,
                'pass' => Config::DB_PASS,
                'port' => 3306,
                'charset' => Config::DB_CHARSET
            ];
            self::$localInstance = new self($config);
        }
        
        return self::$localInstance;
    }
    
    /**
     * ✅ Get REMOTE Database Instance (14.225.209.87) - CHỈ dùng cho team_user
     */
    public static function getRemoteInstance() {
        if (self::$remoteInstance === null) {
            $config = [
                'host' => Config::REMOTE_DB_HOST,
                'name' => Config::REMOTE_DB_NAME,
                'user' => Config::REMOTE_DB_USER,
                'pass' => Config::REMOTE_DB_PASS,
                'port' => 3306,
                'charset' => Config::REMOTE_DB_CHARSET
            ];
            self::$remoteInstance = new self($config);
        }
        
        try {
            self::$remoteInstance->connection->query('SELECT 1');
        } catch (PDOException $e) {
            error_log("Reconnecting remote database...");
            $config = [
                'host' => Config::REMOTE_DB_HOST,
                'name' => Config::REMOTE_DB_NAME,
                'user' => Config::REMOTE_DB_USER,
                'pass' => Config::REMOTE_DB_PASS,
                'port' => 3306,
                'charset' => Config::REMOTE_DB_CHARSET
            ];
            self::$remoteInstance = new self($config);
        }
        
        return self::$remoteInstance;
    }
    
    /**
     * Get Game Database Instance by server_id
     */
    public static function getGameInstance($server_id = null) {
        if ($server_id === null) {
            $server_id = Config::DEFAULT_SERVER_ID;
        }
        
        if (isset(self::$gameInstances[$server_id])) {
            try {
                self::$gameInstances[$server_id]->connection->query('SELECT 1');
                return self::$gameInstances[$server_id];
            } catch (PDOException $e) {
                error_log("Reconnecting game database for server $server_id...");
                unset(self::$gameInstances[$server_id]);
            }
        }
        
        $serverConfig = self::getServerConfig($server_id);
        
        if (!$serverConfig) {
            throw new Exception("Server configuration not found for server_id: " . $server_id);
        }
        
        $config = [
            'host' => $serverConfig['db_host'],
            'name' => $serverConfig['db_name'],
            'user' => $serverConfig['db_user'],
            'pass' => $serverConfig['db_pass'],
            'port' => $serverConfig['db_port'],
            'charset' => Config::DB_CHARSET
        ];
        
        self::$gameInstances[$server_id] = new self($config);
        return self::$gameInstances[$server_id];
    }
    
    /**
     * ✅ Lấy cấu hình server từ LOCAL database (localhost)
     */
    private static function getServerConfig($server_id) {
        if (isset(self::$serverConfigCache[$server_id])) {
            return self::$serverConfigCache[$server_id];
        }
        
        try {
            $localDb = self::getInstance(); // ✅ Dùng LOCAL DB
            $pdo = $localDb->getConnection();
            
            $stmt = $pdo->prepare("
                SELECT db_host, db_name, db_user, db_pass, db_port 
                FROM servers 
                WHERE server_id = ? AND status = 1
                LIMIT 1
            ");
            $stmt->execute([$server_id]);
            $config = $stmt->fetch();
            
            if ($config) {
                self::$serverConfigCache[$server_id] = $config;
            }
            
            return $config ?: null;
            
        } catch (Exception $e) {
            error_log("Failed to get server config: " . $e->getMessage());
            throw new Exception("Failed to get server config: " . $e->getMessage());
        }
    }
    
    /**
     * Lấy danh sách tất cả server đang active (từ LOCAL DB)
     */
    public static function getAllActiveServers() {
        try {
            $localDb = self::getInstance(); // ✅ Dùng LOCAL DB
            $pdo = $localDb->getConnection();
            
            $stmt = $pdo->query("
                SELECT server_id, server_name, db_name, db_host, db_port, created_at 
                FROM servers 
                WHERE status = 1 
                ORDER BY server_id ASC
            ");
            
            return $stmt->fetchAll();
            
        } catch (Exception $e) {
            throw new Exception("Failed to get server list: " . $e->getMessage());
        }
    }
    
    public function getConnection() {
        return $this->connection;
    }
    
    /**
     * ✅ Đóng tất cả connections
     */
    public static function closeAll() {
        self::$localInstance = null;
        self::$remoteInstance = null;
        self::$gameInstances = [];
        self::$serverConfigCache = [];
    }
    
    private function __clone() {}
    
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }
}

register_shutdown_function(function() {
    Database::closeAll();
});