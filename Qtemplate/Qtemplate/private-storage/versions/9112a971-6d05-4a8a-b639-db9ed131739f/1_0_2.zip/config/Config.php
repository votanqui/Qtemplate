<?php
// config/Config.php

class Config {
    // ✅ LOCAL Database - Dùng cho servers và các bảng khác
    const DB_HOST = 'localhost';
    const DB_NAME = 'kpah2d_account';
    const DB_USER = 'kpah2d_kvteam';
    const DB_PASS = '3jYdcVz3jHT6bDQwTKIh';
    const DB_CHARSET = 'utf8mb4';
    
    // ✅ REMOTE Database - CHỈ dùng cho team_user
    const REMOTE_DB_HOST = '14.225.209.87';
    const REMOTE_DB_NAME = 'account';
    const REMOTE_DB_USER = 'root';
    const REMOTE_DB_PASS = '3jYdcVz3jHT6bDQwTKIh';
    const REMOTE_DB_CHARSET = 'utf8mb4';
    
    // API Keys
    const SEPAY_API_KEY = 'API_KEY_CUA_KVTEAM';
    const ACTIVATION_DESCRIPTION_PREFIX = 'kichhoat_';
    
    // VietQR
    const VIETQR_ACCOUNT = '0919332046';
    const VIETQR_BANK = 'MBBank';
    const VIETQR_BANK_NAME = 'Ngân hàng Quân đội (MBBank)';
    const VIETQR_ACCOUNT_NAME = 'TÊN CHỦ TÀI KHOẢN';
    
    // Recharge Prefixes
    const RECHARGE_XU_PREFIX = 'napxu';
    const RECHARGE_LUONG_PREFIX = 'napluong';

    // Exchange Rates
    const XU_EXCHANGE_RATES = [
        10000 => 10000000,
        20000 => 20000000,
        30000 => 30000000,
        50000 => 60000000,
        100000 => 130000000,
        200000 => 280000000,
        300000 => 435000000,
        500000 => 750000000,
        1000000 => 1700000000,
    ];
    
    const LUONG_EXCHANGE_RATE = 20;
    const LUONG_KHOA_PERCENT = 0.5;
    const LUONG_BONUS_MULTIPLIER = 1;
    
    // Activation
    const ACTIVATION_AMOUNT = 20000;
    const ACTIVATION_REWARD_XU = 10000000;
    const ACTIVATION_REWARD_LUONG = 50000;
    
    // JWT
    const JWT_SECRET = 'your-secret-key-change-this-in-production';
    const JWT_ACCESS_EXPIRY = 7200;
    const JWT_REFRESH_EXPIRY = 2592000;
    
    // API
    const API_VERSION = 'v1';
    const TIMEZONE = 'Asia/Ho_Chi_Minh';
    
    // Server
    const DEFAULT_SERVER_ID = 1;
}

date_default_timezone_set(Config::TIMEZONE);